<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['usuario'])) {
    if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'admin') {
        header("Admin/admin-page.php");
        exit();
    } else {
        header("Cliente/cliente-page.php");
        exit();
    }
}

require 'Config/config.php';
require 'php/database.php';
require 'php/clientesfunciones.php';

$db = new Database();
$con = $db->conectar();

$errors = [];

if (!empty($_POST)) {
    // Validar y limpiar los datos enviados por el formulario
    $dni = trim($_POST['dni']);
    $nombres = trim($_POST['nombres']);
    $apellido_paterno = trim($_POST['apellido_paterno']);
    $apellido_materno = trim($_POST['apellido_materno']);
    $celular = trim($_POST['celular']);
    $fecha_nacimiento = trim($_POST['fecha_nacimiento']);
    $correo = trim($_POST['email']);
    $contrasena = trim($_POST['password']);
    $genero = isset($_POST['genero']) ? $_POST['genero'] : '';

    $token = generarToken();

    if (esNulo([$dni, $nombres, $apellido_paterno, $apellido_materno, $celular, $fecha_nacimiento, $correo, $contrasena, $genero])) {
        $errors[] = "Debe llenar todos los campos";
    }
    if (dniExiste($dni, $con)) {
        $errors[] = "El DNI ya está registrado";
    }

    if (!esEmail($correo)) {
        $errors[] = "La direccion de correo electronico no es valida";
    }

    if (validarFechaNacimiento($fecha_nacimiento)) {
        if (validarEdad($fecha_nacimiento)) {
        } else {
            // La edad no es válida, mostrar un mensaje de error
            $errors[] = "Debes tener al menos 18 años";
        }
    } else {
        // La fecha de nacimiento no es válida, mostrar un mensaje de error
        $errors[] = "La fecha de nacimiento proporcionada no es válida.";
    }

    if (!validaPassword($contrasena, $confirmarcontrasena)) {
        $errors[] = "Las contraseñas no coinciden";
    }
    if (emailExiste($correo, $con)) {
        $errors[] = "El correo electronico $correo ya existe";
    }

    if (count($errors) == 0) {
        //encriptamiento de contraseña - investigar más métodos para que al encriptar la encriptación sea diferente en cada contra
        $contrasena = hash('sha512', $contrasena);
        registrarUsuario([$dni, $nombres, $apellido_paterno, $apellido_materno, $celular, $fecha_nacimiento, $correo, $contrasena, $genero, $token], $con);
        echo '
        <script>
            alert("Usuario almacenado exitosamente");

        </script>      
    ';
    } else {
        echo '
        <script>
            alert("Error al registrar usuario");
        </script>
    ';
    }
}


$productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;

$lista_carrito = array();

if ($productos != null) {
    foreach ($productos as $clave => $cantidad) {
        // Se debe asegurar que el producto exista antes de intentar obtener sus detalles
        $sql = $con->prepare("SELECT codigo, foto, descripcion, pventa, id_categoria, $cantidad AS cantidad FROM productos WHERE codigo=?");
        $sql->execute([$clave]);
        // Se obtienen los detalles del producto de la base de datos
        $producto = $sql->fetch(PDO::FETCH_ASSOC);
        // Se verifica si el producto fue encontrado en la base de datos antes de procesarlo
        if ($producto) {
            // Se agregan los detalles del producto al array $lista_carrito
            $lista_carrito[] = $producto;
        }
    }
}
//session_destroy();


$categorias = array();

$consultaCategorias = "SELECT * FROM categorias";
$resultadoCategorias = $con->prepare($consultaCategorias);
$resultadoCategorias->execute();
$categoriasData = $resultadoCategorias->fetchAll(PDO::FETCH_ASSOC);

foreach ($categoriasData as $categoria) {
    $categorias[$categoria['id_categoria']] = $categoria;
}

$sqlProductosCategoria = $con->prepare("
                SELECT codigo, id_categoria, foto, descripcion, stock, pventa
                FROM productos 
                WHERE id_categoria = :id_categoria
            ");
$sqlProductosCategoria->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
$sqlProductosCategoria->execute();
$productosCategoria = $sqlProductosCategoria->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/landing.css" />
    <link rel="stylesheet" href="css/sb-admin-2.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="css/Footer.css" />
    <link rel="stylesheet" href="css/cabeceras.css" />
</head>



<body class="fondo" id="page-top">

    <!-- cabeceras -->
    <div class="content fixed-header">

        <!--Primera cabecera-->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top primeraCabecera" 
         style="height: 35px; background-color: #5EBC50 !important;">
        <div class="navbar-nav" style="padding: 10px 20px; text-align: left;">
            <a class="telefono" style="color: white; font-weight: bold; text-decoration: none; font-size: 15px; margin-left: 30px;">
                <i class="fas fa-phone" style="margin-right: 8px;"></i> Llámanos al: 945853331
            </a>
        </div>
        </nav>


        <!-- Segunda cabecera -->
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top segundaCabecera">

            <!-- Logo (visible solo en pantallas medianas y grandes) -->
            <img src="images/logo-completo.png" onclick="redirectToLanding()" alt="Logo" class="navbar-brand logoPrincipal leftImage d-none d-sm-flex" style="height: 75px; width: auto; margin-top: 10px">
            <!-- Logo (visible solo en pantallas celular) -->
            <img src="images/Icons/logo-icono.png" onclick="redirectToLanding()" alt="Logo" class="navbar-brand logoPrincipal leftImage d-sm-none" style="height: 50px; width: auto;">
            <!-- Fondo oscurecido -->
            <div id="overlay"></div>
            <!-- Apartado buscar -->
           
            <div class="form-container">
                <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="" method="post" autocomplete="off">
                    <div class="input-group search-wrapper">
                        <input type="text" class="form-control bg-light border-0 small" placeholder="Busca un producto..." aria-label="Search" aria-describedby="basic-addon2" name="campo" id="campo">
                        <div class="input-group-append">
                            <button class="btn bg-custom-color" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                    <ul id="lista" class="list-group"></ul>
                </form>
            </div>
          
            <!-- CSS -->
             
            <style>
                /* Fondo oscurecido */
                #overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.6);
                    display: none;
                    z-index: 10;
                }

                /* Estilos de la barra de búsqueda */
                .form-container {
                    position: relative;
                    z-index: 20;
                }

                .navbar-search {
                    width: 300px; /* Tamaño inicial */
                    transition: width 0.3s ease-in-out;
                }

                .navbar-search.expanded {
                    width: 600px; /* Tamaño expandido */
                }

                .search-input {
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 30px;
                    font-size: 16px;
                }

                .search-btn {
                    border-radius: 50%;
                    padding: 10px;
                }
                
            </style>
            
            <!-- JavaScript -->
            
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    var searchInput = document.getElementById("campo");
                    var overlay = document.getElementById("overlay");
                    var searchForm = document.querySelector(".navbar-search");

                    searchInput.addEventListener("focus", function () {
                        overlay.style.display = "block"; // Oscurecer fondo
                        searchForm.classList.add("expanded"); // Expandir barra
                    });

                    overlay.addEventListener("click", function () {
                        overlay.style.display = "none"; // Quitar oscurecimiento
                        searchForm.classList.remove("expanded"); // Contraer barra
                        searchInput.blur(); // Quitar el foco del input
                    });
               });
            </script>
            
            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <!-- Nav Item - Search Redirect (Visible Only on Small Screens) -->
                <li class="nav-item d-sm-none">
                    <a class="nav-link" href="buscar.php">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                </li>
            </ul>

            <!-- Botón de Carrito de Compras -->
            <ul class="navbar-nav mx-auto carro-compras">
                <li class="nav-item">
                    <a href="carritodetalles.php">
                        <img src="images/Icons/carro.png" loading="lazy"></a>
                    <span id="num_cart" class="mr-2" style="margin-left: 0.5vh;"><?php echo $num_cart; ?></span>
                </li>
            </ul>


            <!-- Botón de Iniciar Sesión -->
            <ul class="navbar-nav mx-auto login">
                <li class="nav-item">
                    <span data-toggle="modal" data-target="#loginModal">
                        <img src="images/sesion_index.png" alt="Icono Login" class="mr-2 iconos-categorias" style="height: 30px; width: auto; margin-right: 15px;">
                        <span class="iniciar-sesion-text" style="font-size: 13px;">Iniciar Sesión</span>
                    </span>
                </li>
            </ul>

            
        </nav>
    </div>

        <!--MODAL LOGIN-->
        <div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loginModalLabel">Iniciar Sesión</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="php/login_usuario_be.php" method="POST" id="loginForm">
                        <div class="form-group">
                            <label for="correo">Correo electrónico</label>
                            <input type="email" class="form-control login-input" id="correo" name="correo" placeholder="Correo electrónico..." required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña</label>
                                <!--Un div se agregó-->
                                <div class="password-container"> 
                                    <input type="password" class="form-control login-input" id="contrasena" name="contrasena" placeholder="Contraseña..." required>
                                    <i class="fa-solid fa-eye" id="showPassword" style="display: none;"></i>
                                    <i class="fa-solid fa-eye-slash" id="hidePassword"></i>
                                </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="button-login">Iniciar Sesión</button>
                        </div>
                    </form>
                    <!-- Contenedor para centrar el contenido -->
                    <div class="text-center" style="font-family: Poppins;">
                        <p>¿No tienes cuenta? <span data-toggle="modal" data-target="#registerModal" class="registrate">Registrate</span></p>
                        <p> ¿Olvidaste tu contraseña?<a href="http://localhost/Auxilium-Web3.0/Cliente/recovery.php"> Recuperar</a></p>
                        <label>Otras opciones para ingresar:</label>
                        <!-- Envuelve los botones en un div con la clase text-center -->
                        <div class="text-center">
                            <button class="btn btn-primary" type="button" id="loginWithFacebook">Ingresar con Facebook</button>
                            <button class="btn btn-danger" type="button" id="loginWithGoogle">Ingresar con Google</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


     <!-- Modal de Registro -->
    <!-- Modal de Registro -->
    <div id="registerModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="registerModalLabel">Registro</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de registro -->
                    <form id="registerForm">
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="dni_U">DNI</label>
                                <input type="text" class="form-control" id="dni_U" name="dni_U" placeholder="Ingrese su DNI..." required>
                                <span id="validaDni_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="nombres_U">Nombres</label>
                                <input type="text" class="form-control" id="nombres_U" name="nombres_U" placeholder="Ingrese sus nombres..." required>
                                <span id="validaNombres_U" class="text-danger"></span>
                            </div>

                        </div>
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="apellido_paterno_U">Apellido Paterno</label>
                                <input type="text" class="form-control" id="apellido_paterno_U" name="apellido_paterno_U" placeholder="Ingrese su apellido paterno..." required>
                                <span id="validaApellidoPaterno_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="apellido_materno_U">Apellido Materno</label>
                                <input type="text" class="form-control" id="apellido_materno_U" name="apellido_materno_U" placeholder="Ingrese su apellido materno..." required>
                                <span id="validaApellidoMaterno_U" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="celular_U">Número de Celular</label>
                                <input type="text" class="form-control" id="celular_U" name="celular_U" placeholder="Ingrese su número de celular..." 
                                pattern="9[0-9]{8}" maxlength="9" required 
                                oninput="validarCelular(this)">
                                <span id="validaCelular_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="fecha_nacimiento_U">Fecha de Nacimiento</label>
                                <input type="date" class="form-control" id="fecha_nacimiento_U" name="fecha_nacimiento_U" required 
                                    oninput="validarFechaNacimiento()">
                                <span id="validaFechadenacimiento_U" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="row separador">
                            <div class="col-md-6 position-relative">
                                <label for="email_U">Correo Electrónico</label>
                                <input type="email" class="form-control  w-100" id="email_U" name="email_U" placeholder="Ingrese su correo electrónico..." required>
                                <!--<span id="validaEmail_U" class="text-danger"></span>-->
                            </div>
                            <div class="col-md-6 position-relative">
                                <label for="password_U">Contraseña</label>
                                <input type="password" class="form-control" id="password_U" name="password_U" placeholder="Ingrese su contraseña..." required>
                                <i class="fa-solid fa-eye " id="verPassword" style="display: none;"></i>
                                <i class="fa-solid fa-eye-slash " id="ocultarPassword"></i>
                            </div>
                        </div>
                        <div class="row separador">
                        <span id="validaEmail_U" class="text-danger"></span>
                            <div class="col-md-6 position-relative">
                                <div class="password-icons">
                                    <label for="confirmar_contrasena_U">Confirmar contraseña</label>
                                    <input type="password" class="form-control" id="confirmar_contrasena_U" name="confirmar_contrasena_U" placeholder="Repita la contraseña..." required>
                                    <div class="password-icons">
                                        <i class="fa-solid fa-eye" id="mostIcon" style="display: none;"></i>
                                        <i class="fa-solid fa-eye-slash" id="oculIcon"></i>
                                    </div>
                                </div>
                                <span id="validaPassword_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="genero_U">Género</label><br>
                                <select class="register-comboBox" id="genero_U" name="genero_U" required>
                                    <option value="" disabled selected>Seleccionar Género</option>
                                    <option value="masculino">Masculino</option>
                                    <option value="femenino">Femenino</option>
                                    <option value="otro">Otro</option>
                                </select>
                            </div>
                            <div class="row separador">
                                <div class="col-md-6 position-relative">
                                    <label for="distrito_U">Distrito</label>
                                    <input type="text" class="form-control" id="distrito_U" name="distrito_U" placeholder="Ingrese el distrito..." required>
                                    <span id="validaDistrito_U" class="text-danger"></span>
                                </div>
                                <div class="col-md-6">
                                    <label for="avenida_U">Avenida</label><br>
                                    <input type="text" class="form-control" id="avenida_U" name="avenida_U" placeholder="Ingrese la avenida..." required>
                                    <span id="validaAvenida_U" class="text-danger"></span>
                                </div>
                            </div>
                            <div class="row separador">
                                <div class="col-md-6 position-relative">
                                    <label for="numero_U">Numero</label>
                                    <input type="text" class="form-control" id="numero_U" name="numero_U" placeholder="Ingrese numero de casa..." required>
                                    <span id="validaNumero_U" class="text-danger"></span>
                                </div>
                                <div class="col-md-6">
                                    <label for="descripcion_U">Dpto/Interior/Piso/Lote/Bloque</label><br>
                                    <input type="text" class="form-control" id="descripcion_U" name="descripcion_U" placeholder="Describa su casa..." required>
                                    <span id="validaDescripcion_U" class="text-danger"></span>
                                </div>
                                <!-- Puedes agregar más campos aquí -->
                            </div>
                        </div>
                        <button type="submit" class="button-register ">Crear cuenta</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--cabecera 3 -->
    <div class="content">
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow categoriasCabecera" style="padding: 35px; min-height: 90px;">

            <div class="navbar-nav mx-auto cetegoriasGrupo">
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                        Productos
                    </button>
                    <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                        <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                            Computación
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                            Electrónica
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToNutricion()">
                            Electricidad
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToBelleza()">
                            Ferretería
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                            Redes y Telec.
                        </div>
                    </div>
                </div>
            </div>

            <ul class="navbar-nav mx-auto cetegoriasGrupo">
                <li class="nav-item">
                    <a class="btn btn-categoria" href="#">
                        Quienes somos
                    </a>
                </li>
                <li class="nav-item">
                    <div class="navbar-nav mx-auto cetegoriasGrupo">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                                Servicios
                            </button>
                            <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                                <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                                    Computadoras
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                                    Electrodomésticos
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToNutricion()">
                                    Redes y Telec.
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToBelleza()">
                                    Eléctricas
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                                    Sist. Seguridad
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                                    Ases. Ing. Sistemas.
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                <div class="navbar-nav mx-auto cetegoriasGrupo">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                                Proyectos
                            </button>
                            <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                                <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                                    Ingeniería Civil
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                                    Ingeniería Sistemas
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="btn btn-categoria" href="#">
                        Contactenos
                    </a>
                </li>
            </ul>
        </nav>
    </div>

    <div style="margin-top: 8vh;">
    </div>

    <!-- Main Content -->
<div class="container mt-5" style="margin-bottom: 80px; font-family: Poppins;">
    <h1 class="titulo text-center mb-4">Carrito de Compras</h1>
    <div class="table-responsive">
        <table class="table table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if ($lista_carrito == null) { ?>
                    <tr>
                        <td colspan="5" class="text-center"><b>Lista vacía</b></td>
                    </tr>
                <?php } else { 
                    $total = 0;
                    foreach ($lista_carrito as $producto) {
                        $codigo = $producto['codigo'];
                        $foto = $producto['foto'];
                        $descripcion = $producto['descripcion'];
                        $pventa = $producto['pventa'];
                        $cantidad = $producto['cantidad'];
                        $precio_desc = $pventa;
                        $subtotal = $cantidad * $precio_desc;
                        $total += $subtotal;

                        // Obtener la categoría del producto
                        $id_categoria_producto = $producto['id_categoria'];
                        $nombre_categoria = isset($categorias[$id_categoria_producto]) ? $categorias[$id_categoria_producto]['nombre_categoria'] : 'Categoría Desconocida';

                        // Construir la ruta de la imagen
                        $imagen = "Admin/{$foto}";
                        if (!file_exists($imagen)) {
                            $imagen = "images/nophoto.jpg";
                        }
                ?>
                    <tr>
                        <td>
                            <img src="<?php echo $imagen; ?>" alt="<?php echo $descripcion; ?>" width="80" height="80" class="me-4">
                            <?php echo $descripcion; ?>
                        </td>
                        <td><?php echo MONEDA . number_format($precio_desc, 2, '.', ','); ?></td>
                        <td>
                            <div class="d-flex justify-content-center align-items-center">
                            <button class="btn-cantidad me-2" onclick="actualizarCantidad(<?php echo $codigo; ?>, -1)">−</button>
                            <span id="cantidad_<?php echo $codigo; ?>" class="cantidad-box"><?php echo $cantidad; ?></span>
                            <button class="btn-cantidad ms-2" onclick="actualizarCantidad(<?php echo $codigo; ?>, 1)">+</button>

                            </div>
                        </td>
                        <td>
                            <div id="subtotal_<?php echo $codigo; ?>" name="subtotal[]">
                                <?php echo MONEDA . number_format($subtotal, 2, '.', ','); ?>
                            </div>
                        </td>
                        <td>
                            <a id="eliminar" class="btn btn-danger btn-sm" data-bs-id="<?php echo $codigo; ?>" data-bs-toggle="modal" data-bs-target="#eliminaModal">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                <?php } ?>

                <tr>
                    <td colspan="3"></td>
                    <td colspan="2" class="text-end">
                        <p class="mb-0 fs-5"><strong>Total a pagar:</strong></p>
                        <p class="mb-0 fw-bold fs-4" id="total">
                            <?php echo MONEDA . number_format($total, 2, '.', ','); ?>
                        </p>
                    </td>
                </tr>

            </tbody>
            <?php } ?>
        </table>
    </div>

    <!-- Estilos para mejorar diseño -->
<style>
    .table {
        border-radius: 10px;
        overflow: hidden;
    }

    .table th, .table td {
        padding: 12px;
        vertical-align: middle;
    }

    .btn-cantidad {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    border: 2px solid #5EBC50; /* Color fucsia de Auxilium Farma */
    background-color: white;
    color: #5EBC50;
    font-weight: bold;
    font-size: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.btn-cantidad:hover {
    background-color: #5EBC50;
    color: white;
}

.cantidad-box {
    min-width: 40px;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
}

</style>

    <div class="row mt-4">
        <div class="col-md-5 offset-md-7 d-grid gap-2">
            <button id="realizarPagoBtn" type="button" class="btn btn-success btn-lg    ">Realizar Pago</button>
        </div>
    </div>
</div>

<style>
    #realizarPagoBtn {
    width: 250px; /* Ajusta el ancho como necesites */
    display: block;
    margin: 0 auto; /* Centra el botón */
    background-color: #20aca9; /* Fucsia */
    border-color: #20aca9;
    color: white; /* Texto en blanco */
}

#realizarPagoBtn:hover {
    background-color: #5EBC50; /* Un fucsia más oscuro para el hover */
    border-color: #5EBC50;
}

</style>

    <!-- Modal Mejorado -->
<div class="modal fade" id="eliminaModal" tabindex="-1" role="dialog" aria-labelledby="eliminaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content custom-modal">
            <div class="modal-header">
                <h5 class="modal-title" id="eliminaModalLabel">⚠ Alerta</h5>
                <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Desea eliminar este producto de la lista?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancelar</button>
                <button id="btn-elimina" type="button" class="btn btn-danger" onclick="eliminar()">Eliminar</button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Estilo del modal */
.custom-modal {
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    background: #fff;
}

/* Modal Header */
.custom-modal .modal-header {
    background: #dc3545;
    color: white;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
}

/* Botón de cerrar */
.custom-modal .btn-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    color: white;
    cursor: pointer;
}

/* Modal Body */
.custom-modal .modal-body {
    padding: 20px;
    font-size: 16px;
    text-align: center;
}

/* Modal Footer */
.custom-modal .modal-footer {
    border-top: none;
    padding: 15px;
    display: flex;
    justify-content: space-between;
}

/* Botones */
.custom-modal .btn-outline-secondary {
    border-radius: 8px;
    padding: 8px 15px;
    font-weight: bold;
}

.custom-modal .btn-danger {
    border-radius: 8px;
    padding: 8px 15px;
    font-weight: bold;
}

</style>

<footer class="pie-pagina">
    <div class="grupo-1">
        <div class="row">
            <!-- Primera Parte: Auxilium Farma (visible en pantallas grandes) -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">La Empresa</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1"  >Quienes somos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Contactos</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1"  >Contáctenos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>

            <!-- Segunda Parte: Inkafarma Digital (visible en pantallas grandes) -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Productos</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Computación</a><br>
                                        <a target="_blank" class="paragraph--1" >Electronica</a><br>
                                        <a target="_blank" class="paragraph--1" >Electricidad</a><br>
                                        <a target="_blank" class="paragraph--1" >Ferretería</a><br>
                                        <a target="_blank" class="paragraph--1" >Redes y Telecomunicaciones</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>
            <!-- Tercera Parte: Contáctanos e Inkafono -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Servicio Técnico</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Computadoras</a><br>
                                        <a target="_blank" class="paragraph--1" >Electrodomésticos</a><br>
                                        <a target="_blank" class="paragraph--1" >Plan de Referidos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Instalaciones</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Redes y Telecomunicaciones</a><br>
                                        <a target="_blank" class="paragraph--1" >Eléctricas</a><br>
                                        <a target="_blank" class="paragraph--1" >Sistemas de seguridad</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>

            <!-- Cuarta Parte: Síguenos -->
<div class="col-11 col-md-3 d-none d-md-block">
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3">Proyectos</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body">
                    <mat-panel-description>
                        <div class="link">
                            <a target="_blank" class="paragraph--1" >Ingeniería Civil</a><br>
                            <a target="_blank" class="paragraph--1" >Ingeniería de Sistemas</a><br>
                        </div>
                    </mat-panel-description>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3">Asesoría</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body">
                    <mat-panel-description>
                        <div class="link">
                            <a target="_blank" class="paragraph--1" >Asesoría en Ing. de Sistemas</a><br>
                        </div>
                    </mat-panel-description>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3 text">Nuestras Redes</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body text-center">
                    <a target="_blank" class="social-item d-flex align-items-center" href="https://www.facebook.com/DelgadoElectronic/">
                        <i class="fab fa-facebook-f fa-2x mr-2"></i> Facebook
                    </a>
                    <a target="_blank" class="social-item d-flex align-items-center" href="https://wa.me/945853331?text=Hola,%20quiero%20obtener%20más%20información.">
                        <i class="fab fa-whatsapp fa-2x mr-2"></i> WhatsApp
                    </a>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
</div>

                <!-- Contenedor principal del acordeón -->
            <div id="accordionPadre">
                <!-- Sección de Auxilium Farma -->
                <div class="col-12 col-md-3 d-block d-md-none">
                    <div class="accordion" id="accordionSobreAuxilium">
                        <div class="card">
                            <div class="card-header" id="headingAuxilium">
                                <h5 class="mb-0">
                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseAuxilium" aria-expanded="true" aria-controls="collapseAuxilium">
                                        SOBRE AUXILIUM-FARMA
                                    </button>
                                </h5>
                            </div>
                            <div id="collapseAuxilium" class="collapse" aria-labelledby="headingAuxilium" data-parent="#accordionPadre">
                                <div class="card-body">
                                    <a target="_blank" class="dropdown-item" >Catálogo del mes</a>
                                    <a target="_blank" class="dropdown-item" >Boticas 24 horas</a>
                                    <a target="_blank" class="dropdown-item" >Farmacia Vecina</a>
                                    <a target="_blank" class="dropdown-item" >Apoyo al Paciente</a>
                                    <a target="_blank" class="dropdown-item" >Productos Equivalentes</a>
                                    <a target="_blank" class="dropdown-item" >Derechos Arco</a>
                                    <a target="_blank" class="dropdown-item" >Intercorp y socios estratégicos</a>
                                    <a target="_blank" class="dropdown-item" >Call Center - Términos y Condiciones</a>
                                    <a target="_blank" class="dropdown-item" >Auxilium club</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- Sección de Inkafarma Digital -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionInkafarmaDigital">
                    <div class="card">
                        <div class="card-header" id="headingInkafarmaDigital">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseInkafarmaDigital" aria-expanded="true" aria-controls="collapseInkafarmaDigital">
                                    AUXILIUM-FARMA DIGITAL
                                </button>
                            </h5>
                        </div>
                        <div id="collapseInkafarmaDigital" class="collapse" aria-labelledby="headingInkafarmaDigital" data-parent="#accordionPadre">
                            <div class="card-body">
                                <a target="_blank" class="dropdown-item"  >Blog Auxiliumfarma</a>
                                <a target="_blank" class="dropdown-item"  >Legales de Campañas</a>
                                <a target="_blank" class="dropdown-item"  >Retiro en Tienda</a>
                                <a target="_blank" class="dropdown-item"  >Servicio Express</a>
                                <a target="_blank" class="dropdown-item"  >Zonas de cobertura</a>
                                <a target="_blank" class="dropdown-item"  >Términos y Condiciones Generales</a>
                                <a target="_blank" class="dropdown-item"  >Políticas de privacidad</a>
                                <a target="_blank" class="dropdown-item"  >Comprobante electrónico</a>
                                <a target="_blank" class="dropdown-item"  >Terceros encargados de tratamiento</a>
                                <a target="_blank" class="dropdown-item"  >Términos y condiciones de otros sellers</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección de Contactanos -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionContactanos">
                    <div class="card">
                        <div class="card-header" id="headingContactanos">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseContactanos" aria-expanded="true" aria-controls="collapseContactanos">
                                    CONTACTANOS
                                </button>
                            </h5>
                        </div>
                        <div id="collapseContactanos" class="collapse" aria-labelledby="headingContactanos" data-parent="#accordionPadre">
                            <div class="card-body">
                                <a target="_blank" class="dropdown-item"  >Preguntas Frecuentes</a>
                                <a target="_blank" class="dropdown-item"  >Información Médica</a>
                                <a target="_blank" class="dropdown-item"  >Plan de Referidos</a>
                                <div class="dropdown-item">
                                    <span class="font-weight-bold">Auxiliumfono (Lima)</span>
                                    <span>(511) 314 2020</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección de Síguenos -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionSiguenos">
                    <div class="card">
                        <div class="card-header" id="headingSiguenos">
                            <h5 class="mb-0 text-center">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSiguenos" aria-expanded="true" aria-controls="collapseSiguenos">
                                    SIGUENOS
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSiguenos" class="collapse" aria-labelledby="headingSiguenos" data-parent="#accordionPadre">
                            <div class="card-body text-center">
                                <!-- Ícono de Facebook -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://www.facebook.com/profile.php?id=61552772167929">
                                    <i class="fab fa-facebook-f fa-lg mr-2"></i> Facebook
                                </a>
                                <!-- Ícono de Instagram -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://www.instagram.com/auxiliumfarma.oficial/?next=https%3A%2F%2Fwww.instagram.com%2F">
                                    <i class="fab fa-instagram fa-lg mr-2"></i> Instagram
                                </a>
                                <!-- Ícono de WhatsApp -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://wa.me/993207538?text=Hola,%20quiero%20obtener%20más%20información.">
                                    <i class="fab fa-whatsapp fa-lg mr-2"></i> WhatsApp
                                </a>
                                <!-- Métodos de pago -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center">
                                    <i class="fa fa-credit-card fa-lg mr-2" aria-hidden="true"></i> Métodos de Pago
                                </a>
                                <!-- Medios de pago como Yape y Plin -->
                                <div class="mt-3">
                                    <a class="dropdown-item">
                                        <img src="https://play-lh.googleusercontent.com/y5S3ZIz-ohg3FirlISnk3ca2yQ6cd825OpA0YK9qklc5W8MLSe0NEIEqoV-pZDvO0A8" alt="Yape" class="social-icon"> Yape
                                    </a>
                                    <!-- Métodos de pago adicionales -->
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR03J-2Z2fy1C7oO0bpTJXkorFqz7aa6dNOov9KVS6OvYtRKOfIUICxW3fV04YRzsw-s-8&usqp=CAU" alt="Visa" class="social-icon"> Visa
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://i.pinimg.com/736x/56/fd/48/56fd486a48ff235156b8773c238f8da9.jpg" alt="MasterCard" class="social-icon"> MasterCard
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/1200px-American_Express_logo_%282018%29.svg.png" alt="American Express" class="social-icon"> American Express
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9sjRswrzitSNR2m7lgjeU0cPgq_dWMVV6ww&s" alt="Diners Club" class="social-icon"> Diners Club
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://avatars.githubusercontent.com/u/33136169?s=200&v=4" alt="Pago Efectivo" class="social-icon"> Pago Efectivo
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://cdn-1.webcatalog.io/catalog/mercado-pago/mercado-pago-icon-filled-256.webp?v=1740557321644" alt="Plin" class="social-icon"> Mercado Pago
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQN94zsmpdqN7p2ugqBBrPygthpvfIsDB4QJA&s" alt="Plin" class="social-icon"> Plin
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Derechos reservados -->
        <div class="grupo-2 text-center">
            <small>&copy; 2025 <b>Delgado Electronic</b> - Todos los Derechos Reservados.</small>
        </div>
    </div>

</footer>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bibliotecas externas -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/efe6a408a5.js" crossorigin="anonymous"></script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

   <!-- Tus scripts personalizados -->
    <script src="js/landing.js"></script>
    <script src="js/sb-admin-2.js"></script>




    <script>
        document.addEventListener("DOMContentLoaded", function() {
    /* Eliminar producto */
    let eliminaModal = document.getElementById('eliminaModal');
    eliminaModal.addEventListener('show.bs.modal', function(event) {
        let button = event.relatedTarget;
        let id = button.getAttribute('data-bs-id');
        let buttonElimina = eliminaModal.querySelector('.modal-footer #btn-elimina');
        buttonElimina.value = id;
    });

    function actualizarCantidad(codigo, cambio) {
    let cantidadElemento = document.getElementById('cantidad_' + codigo);
    let cantidadActual = parseInt(cantidadElemento.innerText);

    // Verificar que la cantidad no sea menor a 1
    let nuevaCantidad = cantidadActual + cambio;
    if (nuevaCantidad < 1) {
        nuevaCantidad = 1;
    }

    cantidadElemento.innerText = nuevaCantidad;

    let url = 'Clases/actualizar_carrito.php';
    let formData = new FormData();
    formData.append('action', 'agregar');
    formData.append('codigo', codigo);
    formData.append('cantidad', nuevaCantidad);

    fetch(url, {
        method: 'POST',
        body: formData,
        mode: 'cors'
    }).then(response => response.json())
    .then(data => {
        if (data.ok) {
            let divsubtotal = document.getElementById('subtotal_' + codigo);
            divsubtotal.innerHTML = data.sub;

            // Recalcular el total
            recalcularTotal();
        }
    });
}


    /* Función para recalcular el total */
    function recalcularTotal() {
        let total = 0.00;
        let listaSubtotales = document.getElementsByName('subtotal[]');

        // Sumar todos los subtotales
        listaSubtotales.forEach(subtotal => {
            let monto = parseFloat(subtotal.innerText.replace(/[^\d.]/g, ''));
            total += isNaN(monto) ? 0 : monto;
        });

        // Formatear el total y actualizar en la página
        document.getElementById('total').innerText = 'S/ ' + total.toFixed(2);
    }

    /* Eliminar producto */
    function eliminar() {
        let botonElimina = document.getElementById('btn-elimina');
        let codigo = botonElimina.value;

        let url = 'Clases/actualizar_carrito.php';
        let formData = new FormData();
        formData.append('action', 'eliminar');
        formData.append('codigo', codigo);

        fetch(url, {
            method: 'POST',
            body: formData,
            mode: 'cors'
        }).then(response => response.json())
        .then(data => {
            if (data.ok) {
                location.reload();
            }
        });
    }

    // Hacer globales las funciones
    window.actualizarCantidad = actualizarCantidad;
    window.eliminar = eliminar;
});

    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="js/validacionLogin.js"></script>
    <script src="js/validarRegistro.js"></script>
</body>

</html>