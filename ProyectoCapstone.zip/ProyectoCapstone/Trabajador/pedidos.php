<?php

//session_destroy();

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario'])) {
    header("Location: ../landing-page.php");
    exit();
}

if (isset($_SESSION['usuario'])) {
    if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'usuario') {
        header("Location: ../Cliente/cliente-page.php");
        exit();
    }
}

require '../Config/config.php';
require '../php/database.php';

// Crear una instancia de Database y conectar a la base de datos
$db = new Database();
$con = $db->conectar();

$sql = $con->prepare("SELECT id_venta, id_transaccion, fecha_venta, status, email, id_cliente, direccion_cliente, 
total_venta FROM ventas WHERE estado = 'Pendiente'");

$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);

// Datos ficticios para simular ventas pendientes
$ventasFicticias = [
    [
        'id_venta' => 'VEN1004',
        'id_transaccion' => 'PAY111222333',
        'fecha_venta' => '2024-05-18 09:15:22',
        'status' => 'Pendiente',
        'email' => 'cliente4@example.com',
        'id_cliente' => 'CLI1004',
        'direccion_cliente' => 'Av. Los Jardines 321, Lima',
        'total_venta' => 'S/ 95.30',
        'cliente' => [
            'nombres' => 'Ana',
            'apellido_paterno' => 'Torres',
            'correo' => 'cliente4@example.com',
            'celular' => '987111222',
            'direccion' => 'Av. Los Jardines 321, Lima'
        ],
        'detalles' => [
            [
                'descripcion' => 'Procesador',
                'precio' => 'S/ 700.00',
                'cantidad' => 1
            ],
            [
                'descripcion' => 'Placa madre',
                'precio' => 'S/ 300.00',
                'cantidad' => 1
            ]
        ]
    ],
    [
        'id_venta' => 'VEN1005',
        'id_transaccion' => 'PAY444555666',
        'fecha_venta' => '2024-05-18 11:45:10',
        'status' => 'Pendiente',
        'email' => 'cliente5@example.com',
        'id_cliente' => 'CLI1005',
        'direccion_cliente' => 'Jr. San Martín 654, Arequipa',
        'total_venta' => 'S/ 150.75',
        'cliente' => [
            'nombres' => 'Luis',
            'apellido_paterno' => 'Mendoza',
            'correo' => 'cliente5@example.com',
            'celular' => '987333444',
            'direccion' => 'Jr. San Martín 654, Arequipa'
        ],
        'detalles' => [
            [
                'descripcion' => 'Case gamer',
                'precio' => 'S/ 30.00',
                'cantidad' => 1
            ],
            [
                'descripcion' => 'Microfono profesional',
                'precio' => 'S/ 220.00',
                'cantidad' => 1
            ]
        ]
    ],
    [
        'id_venta' => 'VEN1006',
        'id_transaccion' => 'PAY777888999',
        'fecha_venta' => '2024-05-19 14:20:35',
        'status' => 'Pendiente',
        'email' => 'cliente6@example.com',
        'id_cliente' => 'CLI1006',
        'direccion_cliente' => 'Calle Las Flores 789, Trujillo',
        'total_venta' => 'S/ 65.50',
        'cliente' => [
            'nombres' => 'Sofía',
            'apellido_paterno' => 'Ramírez',
            'correo' => 'cliente6@example.com',
            'celular' => '987555666',
            'direccion' => 'Calle Las Flores 789, Trujillo'
        ],
        'detalles' => [
            [
                'descripcion' => 'Tarjeta ram',
                'precio' => 'S/ 240.00',
                'cantidad' => 2
            ],
            [
                'descripcion' => 'Dispador',
                'precio' => 'S/ 120.00',
                'cantidad' => 3
            ]
        ]
    ]
];

// Combinar resultados reales con ficticios si no hay resultados reales
if (empty($resultado)) {
    $resultado = $ventasFicticias;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Pendientes</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.css" rel="stylesheet">
    
    <style>
        .bg-custom-color {
            background-color: #4e73df;
        }
        .card {
            border-left: 5px solid #4e73df;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        .status-pending {
            background-color: #ffc107;
            color: #000;
        }
        .status-processing {
            background-color: #17a2b8;
            color: white;
        }
        .btn-action {
            margin-right: 5px;
        }
        .total-price {
            font-weight: bold;
            color: #2e59d9;
        }
        .urgent {
            border-left: 5px solid #dc3545 !important;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-custom-color sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="admin-page.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    
                </div>
                <div class="sidebar-brand-text mx-3">Delgado Electronic</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Gestión de Pedidos
            </div>

            <!-- Nav Item - Charts -->
            <li class="nav-item active">
                <a class="nav-link" href="pedidos.php">
                    <i class="fas fa-fw fa-clock"></i>
                    <span>Pendientes</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="entregados.php">
                    <i class="fas fa-fw fa-check-circle"></i>
                    <span>Entregados</span></a>
            </li>
            
            <!-- Divider -->
            <hr class="sidebar-divider">
            
            <!-- Heading -->
            <div class="sidebar-heading">
                Reportes
            </div>
            
            <!-- Nav Item - Reportes -->
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Ventas</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn bg-custom-color d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
                    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar pedido..." aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn bg-custom-color" type="button">
                                    <i class="fas fa-search fa-sm text-white"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar..." aria-label="Search" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn bg-custom-color" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Notificaciones
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Hoy, 10:30 AM</div>
                                        <span class="font-weight-bold">Nuevo pedido recibido #VEN1007</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Hoy, 9:15 AM</div>
                                        Pedido #VEN1004 pendiente por más de 24 horas
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-info">
                                            <i class="fas fa-prescription-bottle-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">Ayer, 5:30 PM</div>
                                        Stock bajo de Ibuprofeno 400mg
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Mostrar todas las notificaciones</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['usuario'] ?? 'Administrador'; ?></span>
                                <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Perfil
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Configuración
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Registro de actividades
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="../php/cerrar_sesion.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Cerrar Sesión
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Pedidos Pendientes</h1>
                        <div>
                            <button class="btn btn-sm bg-custom-color text-white shadow-sm mr-2">
                                <i class="fas fa-download fa-sm text-white-50"></i> Generar Reporte
                            </button>
                            <button class="btn btn-sm btn-success shadow-sm">
                                <i class="fas fa-print fa-sm text-white-50"></i> Imprimir
                            </button>
                        </div>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <!-- Total Pendientes Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Pedidos Pendientes</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($resultado); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Urgentes Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                Pedidos Urgentes</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">2</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-exclamation-triangle fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- En Proceso Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                En Proceso</div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">1</div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-info" role="progressbar" style="width: 33%" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-spinner fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Valor Pendiente Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Valor Pendiente</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">S/ 311.55</div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Productos -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Listado de Pedidos Pendientes</h6>
                            <div class="dropdown no-arrow">
                                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                    <div class="dropdown-header">Opciones:</div>
                                    <a class="dropdown-item" href="#">Exportar a Excel</a>
                                    <a class="dropdown-item" href="#">Filtrar por fecha</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="#">Marcar todos como procesados</a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>N° Venta</th>
                                            <th>Cliente</th>
                                            <th>Fecha</th>
                                            <th>Tiempo</th>
                                            <th>Productos</th>
                                            <th>Total</th>
                                            <th>Estado</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($resultado as $venta): 
                                            // Calcular tiempo transcurrido
                                            $fechaPedido = new DateTime($venta['fecha_venta']);
                                            $ahora = new DateTime();
                                            $intervalo = $fechaPedido->diff($ahora);
                                            $horasTranscurridas = $intervalo->h + ($intervalo->days * 24);
                                            
                                            // Determinar si es urgente (más de 24 horas)
                                            $esUrgente = $horasTranscurridas > 24;
                                        ?>
                                        <tr class="<?php echo $esUrgente ? 'table-warning' : ''; ?>">
                                            <td><?php echo $venta['id_venta']; ?></td>
                                            <td>
                                                <?php 
                                                    $cliente = isset($venta['cliente']) ? $venta['cliente'] : [
                                                        'nombres' => 'Cliente',
                                                        'apellido_paterno' => 'Generico'
                                                    ];
                                                    echo $cliente['nombres'] . ' ' . $cliente['apellido_paterno']; 
                                                ?>
                                            </td>
                                            <td><?php echo $venta['fecha_venta']; ?></td>
                                            <td>
                                                <?php 
                                                    if ($intervalo->d > 0) {
                                                        echo $intervalo->d . 'd ' . $intervalo->h . 'h';
                                                    } else {
                                                        echo $intervalo->h . 'h ' . $intervalo->i . 'm';
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <?php 
                                                    $detalles = isset($venta['detalles']) ? $venta['detalles'] : [
                                                        ['descripcion' => 'Producto genérico', 'cantidad' => 1]
                                                    ];
                                                    echo count($detalles) . ' productos'; 
                                                ?>
                                            </td>
                                            <td class="total-price"><?php echo $venta['total_venta']; ?></td>
                                            <td>
                                                <span class="status-badge <?php echo $venta['status'] == 'Pendiente' ? 'status-pending' : 'status-processing'; ?>">
                                                    <?php echo $venta['status']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-info btn-action" title="Ver detalles">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-primary btn-action" title="Procesar pedido">
                                                    <i class="fas fa-truck"></i>
                                                </button>
                                                <button class="btn btn-sm btn-success btn-action" title="Marcar como entregado">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                                <button class="btn btn-sm btn-danger btn-action" title="Cancelar pedido">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="row" id="pedidos-container" style="margin-top: 2vh;">
                        <?php foreach ($resultado as $venta) : 
                            // Calcular tiempo transcurrido para cada pedido
                            $fechaPedido = new DateTime($venta['fecha_venta']);
                            $ahora = new DateTime();
                            $intervalo = $fechaPedido->diff($ahora);
                            $horasTranscurridas = $intervalo->h + ($intervalo->days * 24);
                            $esUrgente = $horasTranscurridas > 24;
                        ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
                                <div class="card <?php echo $esUrgente ? 'urgent' : ''; ?>">
                                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Pedido #<?php echo $venta['id_venta']; ?></h5>
                                        <div>
                                            <span class="status-badge <?php echo $venta['status'] == 'Pendiente' ? 'status-pending' : 'status-processing'; ?>">
                                                <?php echo $venta['status']; ?>
                                            </span>
                                            <?php if ($esUrgente): ?>
                                                <span class="badge badge-danger ml-2">URGENTE</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <!-- Datos de la venta -->
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Transacción:</strong> <?php echo $venta['id_transaccion']; ?></p>
                                            </div>
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Fecha:</strong> <?php echo $venta['fecha_venta']; ?></p>
                                            </div>
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Tiempo espera:</strong> 
                                                    <?php 
                                                        if ($intervalo->d > 0) {
                                                            echo $intervalo->d . ' días, ' . $intervalo->h . ' horas';
                                                        } else {
                                                            echo $intervalo->h . ' horas, ' . $intervalo->i . ' minutos';
                                                        }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                        <hr>

                                        <!-- Datos del cliente -->
                                        <h5 class="card-title"><i class="fas fa-user mr-2"></i>Datos del Cliente</h5>

                                        <?php
                                        $cliente = isset($venta['cliente']) ? $venta['cliente'] : [
                                            'nombres' => 'Cliente',
                                            'apellido_paterno' => 'Generico',
                                            'correo' => 'cliente@ejemplo.com',
                                            'celular' => '999888777',
                                            'direccion' => 'Dirección no especificada'
                                        ];
                                        ?>
                                        <div class="row mb-3">
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Nombres:</strong> <?php echo $cliente['nombres'] . ' ' . $cliente['apellido_paterno']; ?></p>
                                            </div>
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Email:</strong> <?php echo $cliente['correo']; ?></p>
                                            </div>
                                            <div class="col-md-4">
                                                <p class="mb-1"><strong>Celular:</strong> <?php echo $cliente['celular']; ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <p class="mb-1"><strong>Dirección de entrega:</strong> <?php echo $cliente['direccion']; ?></p>
                                            </div>
                                        </div>
                                        <hr>

                                        <!-- Detalles de la venta -->
                                        <h5 class="card-title"><i class="fas fa-list-ul mr-2"></i>Detalles del Pedido</h5>

                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead class="thead-light">
                                                    <tr>
                                                        <th>Producto</th>
                                                        <th>Precio Unitario</th>
                                                        <th>Cantidad</th>
                                                        <th>Subtotal</th>
                                                        <th>Stock</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $detalles = isset($venta['detalles']) ? $venta['detalles'] : [
                                                        [
                                                            'descripcion' => 'Producto genérico',
                                                            'precio' => 'S/ 0.00',
                                                            'cantidad' => 1,
                                                            'stock' => 10
                                                        ]
                                                    ];
                                                    
                                                    foreach ($detalles as $detalle) : 
                                                        $stockBajo = isset($detalle['stock']) && $detalle['stock'] < 5;
                                                    ?>
                                                    <tr class="<?php echo $stockBajo ? 'table-danger' : ''; ?>">
                                                        <td><?php echo $detalle['descripcion']; ?></td>
                                                        <td><?php echo $detalle['precio']; ?></td>
                                                        <td><?php echo $detalle['cantidad']; ?></td>
                                                        <td>
                                                            <?php 
                                                            $precio = floatval(str_replace('S/ ', '', $detalle['precio']));
                                                            $subtotal = $precio * $detalle['cantidad'];
                                                            echo 'S/ ' . number_format($subtotal, 2);
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php if (isset($detalle['stock'])): ?>
                                                                <?php echo $detalle['stock']; ?>
                                                                <?php if ($stockBajo): ?>
                                                                    <span class="badge badge-warning ml-1">BAJO</span>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>

                                        <hr>

                                        <!-- Total a pagar y acciones -->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="alert alert-info">
                                                    <h5 class="alert-heading">Información del Pedido</h5>
                                                    <p class="mb-1"><strong>Estado actual:</strong> <?php echo $venta['status']; ?></p>
                                                    <p class="mb-1"><strong>Tiempo de espera:</strong> 
                                                        <?php 
                                                            if ($intervalo->d > 0) {
                                                                echo $intervalo->d . ' días, ' . $intervalo->h . ' horas';
                                                            } else {
                                                                echo $intervalo->h . ' horas, ' . $intervalo->i . ' minutos';
                                                            }
                                                        ?>
                                                    </p>
                                                    <?php if ($esUrgente): ?>
                                                        <p class="mb-0 text-danger"><strong>Atención:</strong> Este pedido lleva más de 24 horas pendiente.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6 text-right">
                                                <div class="d-flex justify-content-end align-items-center">
                                                    <div class="mr-4">
                                                        <h4 class="mb-0">Total a Cobrar:</h4>
                                                        <h3 class="total-price"><?php echo $venta['total_venta']; ?></h3>
                                                    </div>
                                                    <div>
                                                        <button class="btn btn-primary mr-2">
                                                            <i class="fas fa-truck mr-1"></i> Procesar
                                                        </button>
                                                        <button class="btn btn-success mr-2">
                                                            <i class="fas fa-check mr-1"></i> Entregado
                                                        </button>
                                                        <button class="btn btn-danger">
                                                            <i class="fas fa-times mr-1"></i> Cancelar
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <small>&copy; 2024 <b>Auxilium Farma</b> - Todos los Derechos Reservados.</small>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">¿Listo para salir?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Seleccione "Cerrar sesión" a continuación si está listo para finalizar su sesión actual.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                    <a class="btn btn-primary" href="../php/cerrar_sesion.php">Cerrar Sesión</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.js"></script>

    <!-- Page level plugins -->
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <!-- script src="../vendor/datatables/jquery.dataTables.min.js"></script> -->  
    <!-- script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script> -->
     
    <!-- Page level custom scripts -->
    <!--script src="../js/demo/datatables-demo.js"></script>  -->
    
    <script>
        $(document).ready(function() {
            // Inicializar DataTable
            $('#dataTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.20/i18n/Spanish.json"
                },
                "order": [[2, "desc"]] // Ordenar por fecha descendente
            });
            
            // Mostrar detalles del pedido al hacer clic en el botón
            $('.btn-info').click(function() {
                var card = $(this).closest('tr').next().find('.card');
                card.toggleClass('d-none');
            });
        });
    </script>

</body>

</html>