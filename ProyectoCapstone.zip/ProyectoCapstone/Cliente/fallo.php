<?php 

    echo "Error al realizar el pago";

?>