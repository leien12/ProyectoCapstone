<?php
session_start();

// Verificar si hay productos en el carrito
if (!isset($_SESSION['carrito']['productos'])) {
    header("Location: carritodetalles_cliente.php");
    exit();
}

// Obtener datos de la compra simulada
$compra = json_decode(file_get_contents('php://input'), true) ?: 
          (isset($_SESSION['ultima_compra']) ? $_SESSION['ultima_compra'] : null);

if (!$compra && isset($_GET['simulacion'])) {
    $compra = [
        'id' => 'SIM-' . strtoupper(uniqid()),
        'total' => array_sum(array_map(function($p) { return $p['subtotal']; }, $_SESSION['carrito']['productos'])),
        'fecha' => date('d/m/Y H:i:s')
    ];
}

// Vaciar carrito después de mostrar el éxito
unset($_SESSION['carrito']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pago Exitoso - Proyecto Universitario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-success text-center">
            <h4 class="alert-heading">¡Compra simulada con éxito!</h4>
            <p>Esta es una simulación para fines académicos.</p>
            
            <?php if ($compra): ?>
            <hr>
            <p><strong>ID de Transacción:</strong> <?php echo htmlspecialchars($compra['id']); ?></p>
            <p><strong>Total:</strong> <?php echo MONEDA . number_format($compra['total'], 2); ?></p>
            <p><strong>Fecha:</strong> <?php echo htmlspecialchars($compra['fecha']); ?></p>
            <?php endif; ?>
            
            <hr>
            <a href="../Cliente/cliente-page.php" class="btn btn-primary mt-3">Volver a la tienda</a>
        </div>
    </div>
</body>
</html>