<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario'])) {
    // Si hay una sesión iniciada, redirigir a cliente-page.php
    header("Location: ../landing-page.php");
    exit(); // Asegurarse de que el script se detenga después de la redirección
}

if (isset($_SESSION['usuario'])) {
    if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'admin') {
        header("Location: ../Admin/admin-page.php");
        exit();
    }
}

require '../Config/config.php';
require '../php/database.php';

// Crear una instancia de Database y conectar a la base de datos
$db = new Database();
$con = $db->conectar();



$sql_venta = $con->prepare("SELECT id_venta, id_transaccion, fecha_venta, status, email, id_cliente, direccion_cliente, 
total_venta, estado FROM ventas WHERE id_cliente = :dni");
$sql_venta->bindParam(':dni', $_SESSION['dni']);
$sql_venta->execute();
$resultado = $sql_venta->fetchAll(PDO::FETCH_ASSOC);

// Consulta SQL para seleccionar los datos del usuario utilizando el DNI
$sql = $con->prepare("SELECT nombres, apellido_paterno, apellido_materno, celular, correo, direccion FROM usuarios WHERE dni = :dni");
$sql->bindParam(':dni', $_SESSION['dni']);
$sql->execute();
$usuario = $sql->fetch(PDO::FETCH_ASSOC);

// Asignar los datos del usuario a variables individuales
$nombres = $usuario['nombres'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Compras</title>
    <link rel="stylesheet" href="../css/landing.css" />
    <link rel="stylesheet" href="../css/sb-admin-2.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body class="fondo" id="page-top">

    <div class="content">

        <nav class="navbar navbar-expand navbar-light topbar mb-4 static-top primeraCabecera">
            <div class="navbar-nav">
                <a class="telefono" href="https://wa.link/knd9eq">Llamanos al: 919285031</a>
            </div>

            <div class="navbar-nav ml-auto">
                <a href="https://www.facebook.com/profile.php?id=61552772167929" class=" fa fa-facebook"></a>
                <a href="https://www.instagram.com/auxiliumfarma.oficial/?next=https%3A%2F%2Fwww.instagram.com%2F" class="fa fa-instagram"></a>
            </div>
        </nav>

        <!-- Segunda Cabecera -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top segundaCabecera">

            <!-- Logo (visible solo en pantallas medianas y grandes) -->
            <img src="../images/logo-completo.png" onclick="redirectToCliente()" alt="Logo" class="navbar-brand logoPrincipal d-none d-sm-flex" style="height: 38px; width: auto;">
            <!-- Logo (visible solo en pantallas celular) -->
            <img src="../images/Icons/logo-icono.png" onclick="redirectToCliente()" alt="Logo" class="navbar-brand logoPrincipal d-sm-none" style="height: 50px; width: auto;">

            <div class="form-container">
                <form class="form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="" method="post" autocomplete="off">
                    <div class="input-group">
                        <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar..." aria-label="Search" aria-describedby="basic-addon2" name="campo" id="campo">
                        <div class="input-group-append">
                            <button class="btn bg-custom-color" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                    <ul id="lista" class="list-group"></ul>
                </form>
            </div>

            <!-- Botón de Bienvenido -->
            <ul class="navbar-nav mx-auto d-none d-sm-flex">
                <li class="nav-item">
                    <a class="bienvenido" href="datos_usuario.php">
                        Bienvenido, <?php echo $nombres; ?>
                    </a>
                </li>
            </ul>

            <div class="bienvenido mx-auto d-sm-none">
                <a class="" href="datos_usuario.php">
                    <label><?php echo $_SESSION['nombres']; ?></label>
                </a>
            </div>

            <!-- Botón de Carrito de Compras -->
            <ul class="navbar-nav mx-auto carro-compras">
                <li class="nav-item">
                    <a href="carritodetalles_cliente.php">
                        <img src="../images/Icons/carro.png" loading="lazy"></a>
                    <span id="num_cart" class="mr-2" style="margin-left: 0.5vh;"><?php echo $num_cart; ?></span>
                </li>
            </ul>

            <!-- Botón de Cerrar Sesion -->
            <ul class="navbar-nav mx-auto d-none d-sm-flex">
                <li class="nav-item">
                    <a class="cerrarSesion" href="../php/cerrar_sesion.php">Cerrar Sesion</a>
                </li>
            </ul>

            <ul class="navbar-nav mx-auto d-sm-none">
                <li class="nav-item">
                    <a class="cerrarSesion" href="../php/cerrar_sesion.php">
                        <img src="../images/Icons/cerrar-icono.png" class="" style="height: 30px; width: auto;margin-right: 10px;">
                    </a>
                </li>
            </ul>

        </nav>


        <!-- Cabecera de Categorías -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top categoriasCabecera">

            <!-- Solo se muestra "CATEGORÍAS" en pantallas pequeñas -->
            <div class="navbar-nav mx-auto cetegoriasGrupo d-none d-sm-flex">
                <button class="btn btn-secondary dropdown-toggle custom-button" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Categorías
                </button>
                <div class="dropdown-menu custom-dropdown-menu" aria-labelledby="categoriasDropdown">
                    <!-- Opciones de categorías -->
                    <div class="dropdown-item" onclick="redirectToFarmacia()">
                        <span>Farmacia</span>
                    </div>
                    <div class="dropdown-item" onclick="redirectToSuplementos()">
                        <span>Suplementos y Vitaminas</span>
                    </div>
                    <div class="dropdown-item" onclick="redirectToNutricion()">
                        <span>Nutrición</span>
                    </div>
                    <div class="dropdown-item" onclick="redirectToBelleza()">
                        <span>Cuidado y Belleza</span>
                    </div>
                    <div class="dropdown-item" onclick="redirectToAromaterapia()">
                        <span>Aromaterapia</span>
                    </div>
                </div>
            </div>


            <!-- Menú desplegable para pantallas pequeñas -->
            <div class="navbar-nav mx-auto cetegoriasGrupo">
                <div class="dropdown">
                    <button class="btn btn-primary dropdown-toggle d-sm-none custom-button" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Categorías
                    </button>
                    <div class="dropdown-menu custom-dropdown-menu" aria-labelledby="categoriasDropdown">
                        <!-- Opciones de categorías -->
                        <div class="dropdown-item" onclick="redirectToFarmacia()">
                            <span>Farmacia</span>
                        </div>
                        <div class="dropdown-item" onclick="redirectToSuplementos()">
                            <span>Suplementos y Vitaminas</span>
                        </div>
                        <div class="dropdown-item" onclick="redirectToNutricion()">
                            <span>Nutrición</span>
                        </div>
                        <div class="dropdown-item" onclick="redirectToBelleza()">
                            <span>Cuidado y Belleza</span>
                        </div>
                        <div class="dropdown-item" onclick="redirectToAromaterapia()">
                            <span>Aromaterapia</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mostrar opciones de categorías en pantallas medianas y grandes -->
            <div class="navbar-nav mx-auto cetegoriasGrupo d-none d-sm-flex">
                <div class="grupos" onclick="redirectToFarmacia()">
                    <span class="mr-4">
                        <img src="../images/Icons/farmacia-icono.png" alt="Icono Categoría 1" class="mr-2 iconos-categorias">
                        Farmacia
                    </span>
                </div>

                <div class="grupos" onclick="redirectToSuplementos()">
                    <span class="mr-4">
                        <img src="../images/Icons/vitamina-icono.png" alt="Icono Categoría 2" class="mr-2 iconos-categorias">
                        Suplementos y Vitaminas
                    </span>
                </div>

                <div class="grupos" onclick="redirectToNutricion()">
                    <span class="mr-4">
                        <img src="../images/Icons/nutricion-icono.png" alt="Icono Categoría 1" class="mr-2 iconos-categorias">
                        Nutrición
                    </span>
                </div>

                <div class="grupos" onclick="redirectToBelleza()">
                    <span class="mr-4">
                        <img src="../images/Icons/belleza-icono.png" alt="Icono Categoría 2" class="mr-2 iconos-categorias">
                        Cuidado y Belleza
                    </span>
                </div>

                <div class="grupos" onclick="redirectToAromaterapia()">
                    <span class="mr-4">
                        <img src="../images/Icons/aromaterapia-icono.png" alt="Icono Categoría 1" class="mr-2 iconos-categorias">
                        Aromaterapia
                    </span>
                </div>
            </div>
        </nav>
    </div>

    <!-- Page Wrapper -->
    <div id="wrapper" style="margin-top: -70px;">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-custom-color sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Opciones
            </div>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="datos_usuario.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Datos Personales</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="cambio_contrasena.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Seguridad</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="compras_cliente.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Mis Compras</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>

        <!-- Content Productos -->
        <div class="container-fluid estiloLetra">
            <h2>Mis Compras</h2>

            <div class="row" id="pedidos-container" style="margin-top: 4vh;">
                <?php foreach ($resultado as $venta) : ?>
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
                        <div class="card">
                            <div class="card-body">
                                <!-- Datos de la venta -->
                                <div class="row">
                                    <div class="col">
                                        <h5 class="card-title">Transacción: <?php echo $venta['id_transaccion']; ?></h5>
                                    </div>
                                    <div class="col">
                                        <h5 class="card-title">Fecha: <?php echo $venta['fecha_venta']; ?></h5>
                                    </div>
                                </div>
                                <hr> <!-- Línea horizontal para separar los datos de la venta de los datos del cliente -->

                                <!-- Datos del cliente -->
                                <h5 class="card-title">Datos del Cliente</h5>

                                <?php
                                // Consulta para obtener los datos del cliente asociado a esta venta
                                $sql_cliente = $con->prepare("SELECT * FROM usuarios WHERE dni = :id_cliente");
                                $sql_cliente->bindParam(':id_cliente', $venta['id_cliente']);
                                $sql_cliente->execute();
                                $cliente = $sql_cliente->fetch(PDO::FETCH_ASSOC);
                                ?>
                                <div class="row">
                                    <div class="col">
                                        <p class="card-text">Nombres: <?php echo $cliente['nombres'] . ' ' . $cliente['apellido_paterno']; ?></p>
                                    </div>
                                    <div class="col">
                                        <p class="card-text">Email: <?php echo $cliente['correo']; ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <p class="card-text">Celular: <?php echo $cliente['celular']; ?></p>
                                    </div>
                                    <div class="col">
                                        <p class="card-text">Dirección: <?php echo $cliente['direccion']; ?></p>
                                    </div>
                                </div>
                                <hr> <!-- Línea horizontal para separar -->

                                <!-- Detalles de la venta -->
                                <h5 class="card-title">Detalles de la Venta</h5>

                                <?php
                                // Consulta para obtener todos los detalles de ventas asociados a esta venta
                                $sql_detalles_venta = $con->prepare("SELECT * FROM detalles_ventas WHERE id_venta = :id_venta");
                                $sql_detalles_venta->bindParam(':id_venta', $venta['id_venta']);
                                $sql_detalles_venta->execute();
                                $detalles_venta = $sql_detalles_venta->fetchAll(PDO::FETCH_ASSOC);
                                ?>

                                <?php foreach ($detalles_venta as $detalle) : ?>
                                    <div class="row">
                                        <div class="col-6">
                                            <p class="card-text">Descripción: <?php echo $detalle['descripcion']; ?></p>
                                        </div>
                                        <div class="col-3">
                                            <p class="card-text">Precio: <?php echo $detalle['precio']; ?></p>
                                        </div>
                                        <div class="col-3">
                                            <p class="card-text">Cantidad: <?php echo $detalle['cantidad']; ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>

                                <hr> <!-- Línea horizontal para separar -->

                                <!-- Total a pagar -->
                                <div class="row">
                                    <div class="col">
                                        <h4 class="card-text">Total Pagado: <?php echo $venta['total_venta']; ?></h4>
                                    </div>
                                    <div class="col">
                                        <p class="card-text">Estado: <?php echo $venta['estado']; ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>


    <footer class="pie-pagina">
        <div class="grupo-1">
            <div class="box">
                <figure>
                    <a href="#" class="logo">
                        <img src="../images/logo-completo.png" alt="Logo">
                    </a>
                </figure>
            </div>
            <div class="box">
                <h2>Sobre nosotros</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea itaque dolor tempore. Placeat quis ex
                    recusandae dignissimos, necessitatibus soluta, dolore accusantium blanditiis, alias libero eius
                    laborum quos cupiditate saepe fugit?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quam repellat quasi dignissimos nemo, iure
                    blanditiis nesciunt assumenda voluptatum voluptatem non dolorum id porro deserunt excepturi
                    temporibus veniam tempora laborum nostrum!</p>
            </div>
            <div class="box">
                <h2>Siguenos</h2>
                <div class="red-social">
                    <a href="https://www.facebook.com/profile.php?id=61552772167929" class="fa fa-facebook"></a>
                    <a href="https://www.instagram.com/auxiliumfarma.oficial/?next=https%3A%2F%2Fwww.instagram.com%2F" class="fa fa-instagram"></a>
                    <a href="#" class="fa-brands fa-linkedin"></a>
                    <!---<a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa-brands fa-tiktok"></a>-->
                </div>
            </div>
        </div>
        <div class="grupo-2">
            <small>&copy; 2024 <b>Auxilium Farma</b> - Todos los Derechos Reservados.</small>
        </div>
    </footer>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bibliotecas externas -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/efe6a408a5.js" crossorigin="anonymous"></script>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Tus scripts personalizados -->
    <script src="../js/cliente.js"></script>
    <script src="../js/sb-admin-2.js"></script>


</body>

</html>