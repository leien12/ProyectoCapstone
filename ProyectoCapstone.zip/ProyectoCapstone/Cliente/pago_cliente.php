<?php
session_start();

// Verificar sesión y carrito
if (!isset($_SESSION['usuario']) || !isset($_SESSION['carrito']['productos'])) {
    header("Location: ../landing-page.php");
    exit();
}

require '../Config/config.php';
require '../php/database.php';

$db = new Database();
$con = $db->conectar();

// Obtener productos del carrito
$productos_carrito = $_SESSION['carrito']['productos'];
$lista_carrito = array();
$total = 0;

foreach ($productos_carrito as $codigo => $cantidad) {
    $sql = $con->prepare("SELECT codigo, descripcion, pventa FROM productos WHERE codigo = ?");
    $sql->execute([$codigo]);
    $producto = $sql->fetch(PDO::FETCH_ASSOC);
    
    if ($producto) {
        $producto['cantidad'] = $cantidad;
        $producto['subtotal'] = $producto['pventa'] * $cantidad;
        $lista_carrito[] = $producto;
        $total += $producto['subtotal'];
    }
}

// Obtener datos del usuario
$sql = $con->prepare("SELECT nombres, apellido_paterno, apellido_materno, celular, direccion FROM usuarios WHERE dni = ?");
$sql->execute([$_SESSION['dni']]);
$usuario = $sql->fetch(PDO::FETCH_ASSOC);

// Simular ID de transacción (para proyecto universitario)
$transaccion_id = 'SIM-' . strtoupper(uniqid());
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proceso de Pago - Proyecto Universitario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .producto-img {
            max-width: 80px;
            height: auto;
        }
        .resumen-pago {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
        }
        .btn-pagar {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            padding: 12px 20px;
            border-radius: 8px;
            border: none;
            transition: all 0.3s;
        }
        .btn-pagar:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
        .simulador-pago {
            display: none;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Incluye tu cabecera aquí (igual que en datos_usuario.php) -->
    
    <div class="container mt-5 mb-5">
        <h1 class="text-center mb-4">Resumen de Compra</h1>
        
        <div class="row">
            <!-- Resumen de productos -->
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5>Productos en el carrito</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Precio Unitario</th>
                                    <th>Cantidad</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($lista_carrito as $producto): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($producto['descripcion']); ?></td>
                                    <td><?php echo MONEDA . number_format($producto['pventa'], 2); ?></td>
                                    <td><?php echo $producto['cantidad']; ?></td>
                                    <td><?php echo MONEDA . number_format($producto['subtotal'], 2); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Datos de envío y pago -->
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5>Datos de Envío</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombres'] . ' ' . $usuario['apellido_paterno'] . ' ' . $usuario['apellido_materno']); ?></p>
                        <p><strong>Dirección:</strong> <?php echo htmlspecialchars($usuario['direccion']); ?></p>
                        <p><strong>Teléfono:</strong> <?php echo htmlspecialchars($usuario['celular']); ?></p>
                    </div>
                </div>
                
                <div class="card resumen-pago">
                    <h5 class="card-title">Resumen del Pago</h5>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <span><?php echo MONEDA . number_format($total, 2); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Envío:</span>
                        <span><?php echo MONEDA . '0.00'; ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between fw-bold">
                        <span>Total a pagar:</span>
                        <span><?php echo MONEDA . number_format($total, 2); ?></span>
                    </div>
                    
                    <!-- Botón de pago simulado -->
                    <div class="d-grid mt-4">
                        <button id="btn-pagar" class="btn-pagar">
                            <i class="fas fa-credit-card me-2"></i> Proceder al Pago
                        </button>
                    </div>
                    
                    <!-- Simulador de pago (aparece al hacer clic) -->
                    <div id="simulador-pago" class="simulador-pago">
                        <h5 class="text-center mb-3">Simulador de Pago</h5>
                        <div class="mb-3">
                            <label class="form-label">Número de tarjeta</label>
                            <input type="text" class="form-control" value="4242 4242 4242 4242" readonly>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Fecha expiración</label>
                                <input type="text" class="form-control" value="12/25" readonly>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">CVV</label>
                                <input type="text" class="form-control" value="123" readonly>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nombre en tarjeta</label>
                            <input type="text" class="form-control" value="TITULAR TARJETA" readonly>
                        </div>
                        <button id="btn-confirmar-pago" class="btn btn-success w-100">
                            Confirmar Pago Simulado
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de confirmación -->
    <div class="modal fade" id="modalExito" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">¡Pago Exitoso!</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Transacción ID: <?php echo $transaccion_id; ?></p>
                    <p>Total pagado: <?php echo MONEDA . number_format($total, 2); ?></p>
                    <p>Gracias por tu compra. Esta es una simulación para fines académicos.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <a href="pago_exitoso.php" class="btn btn-primary">Ver comprobante</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mostrar simulador de pago al hacer clic
        document.getElementById('btn-pagar').addEventListener('click', function() {
            this.style.display = 'none';
            document.getElementById('simulador-pago').style.display = 'block';
        });
        
        // Simular pago exitoso
        document.getElementById('btn-confirmar-pago').addEventListener('click', function() {
            // Mostrar modal de éxito
            const modal = new bootstrap.Modal(document.getElementById('modalExito'));
            modal.show();
            
            // Opcional: Guardar en localStorage para la página de éxito
            localStorage.setItem('ultimaCompra', JSON.stringify({
                id: '<?php echo $transaccion_id; ?>',
                total: <?php echo $total; ?>,
                fecha: new Date().toLocaleString()
            }));
        });
    </script>
</body>
</html>