//Se recarla la pagina hacia el index.php
window.onload = function(){
    window.location.href = "index.php";
}