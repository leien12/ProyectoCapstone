document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("loginForm").addEventListener("submit", function (event) {
        event.preventDefault(); // Evita el envío del formulario

        let correo = document.getElementById("correo").value.trim();
        let contrasena = document.getElementById("contrasena").value.trim();

        let emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!emailRegex.test(correo)) {
            Swal.fire({ title: "Error", text: "Correo inválido", icon: "error" });
            return;
        }

        // Crear un objeto URLSearchParams para enviar datos correctamente
        let formData = new URLSearchParams();
        formData.append("correo", correo);
        formData.append("contrasena", contrasena);

        // Enviar los datos al backend con AJAX
        fetch("php/login_usuario_be.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: formData.toString()
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    title: "Bienvenid@",
                    text: data.message,
                    icon: "success"
                }).then(() => {
                    window.location.href = data.redirect; // Redirige según el tipo de usuario
                });
            } else {
                Swal.fire({ title: "Error", text: data.message, icon: "error" });
            }
        })
        .catch(error => {
            console.error("Error:", error);
            Swal.fire({ title: "Error", text: "Hubo un problema con el servidor.", icon: "error" });
        });
    });
});
