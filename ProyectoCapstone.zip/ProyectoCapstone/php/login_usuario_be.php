<?php
session_start();
include 'database.php';
//Se da a entender que la respuesta se dará en JSON 
//Para el frontend
header('Content-Type: application/json');

try {
    //El database hace la conexión con la base de datos
    $conexion = Database::conectar();
    //Recepciona y limpia los espacios en blanco.
    $correo = trim($_POST['correo']);
    $contrasena = trim($_POST['contrasena']);

    // Buscar usuario en la tabla unificada de usuarios
    $stmt_usuario = $conexion->prepare("SELECT * FROM usuarios WHERE correo = :correo");
    $stmt_usuario->bindParam(':correo', $correo);
    $stmt_usuario->execute();
    $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

    // Verificación de credenciales y redirección según rol
    if ($usuario && password_verify($contrasena, $usuario['contrasena'])) {
        $_SESSION['usuario'] = $usuario['correo'];
        $_SESSION['tipo'] = $usuario['rol']; // Almacena el rol en la sesión

    // Redirección según el rol del usuario
    switch ($usuario['rol']) {
        case 'admin':
            $_SESSION['dni'] = $usuario['dni'] ?? null;
            $_SESSION['direccion'] = $usuario['direccion'] ?? null;
            echo json_encode([
                "success" => true, 
                "message" => "Inicio de sesión como Administrador.", 
                "redirect" => "/ProyectoCapstone/Admin/admin-page.php"
            ]);
            break;
            
        case 'vendedor':
            $_SESSION['dni'] = $usuario['dni'] ?? null;
            $_SESSION['direccion'] = $usuario['direccion'] ?? null;
            echo json_encode([
                "success" => true, 
                "message" => "Bienvenido Trabajador.", 
                "redirect" => "/ProyectoCapstone/Trabajador/pedidos.php"
            ]);
            break;
            
        case 'cliente':
            if ($usuario['estado'] == 0) {
                echo json_encode([
                    "success" => false, 
                    "message" => "Cuenta inactiva"
                ]);
                break;
            }
            $_SESSION['dni'] = $usuario['dni'] ?? null;
            $_SESSION['direccion'] = $usuario['direccion'] ?? null;
            echo json_encode([
                "success" => true, 
                "message" => "Inicio de sesión exitoso.", 
                "redirect" => "/ProyectoCapstone/Cliente/cliente-page.php"
            ]);
            break;
            
        default:
            echo json_encode([
                "success" => false, 
                "message" => "Rol de usuario no reconocido"
            ]);
    }
    exit;
    } else {
        echo json_encode([
            "success" => false, 
            "message" => "Usuario o contraseña incorrectos. Verifique sus datos."
        ]);
        exit;
    }

    //Si el error ocurre en laa base de datos se mandará un mensaje 
    //de error de conexión
}catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Error de conexión: " . $e->getMessage()]);
    exit;
}
