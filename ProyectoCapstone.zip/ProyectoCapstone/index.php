<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['usuario'])) {
    // Si ya hay una sesión iniciada, redirige al usuario según su tipo
    if (isset($_SESSION['tipo']) && $_SESSION['tipo'] == 'admin') {
        header("Admin/productos_admin.php");
        exit();
    } else {
        header("Cliente/cliente-page.php");
        exit();
    }
}

//
require 'Config/config.php';
require 'php/database.php';
require 'php/clientesfunciones.php';



$db = new Database();
$con = $db->conectar();

if (isset($_POST['accion']) && $_POST['accion'] === 'agregarU') {
    
    $dni = trim($_POST["dni_U"]);
    $nombre = trim($_POST["nombres_U"]);
    $apellido_paterno = trim($_POST["apellido_paterno_U"]);
    $apellido_materno = trim($_POST["apellido_materno_U"]);
    $telefono = trim($_POST["celular_U"]);
    $fecha_nacimiento = trim($_POST["fecha_nacimiento_U"]);
    $correo = trim($_POST["email_U"]);
    $contrasena = trim($_POST["password_U"]);
    $genero = trim($_POST["genero_U"]);
    $distrito = trim($_POST['distrito_U']);
    $avenida = trim($_POST['avenida_U']);
    $numero = trim($_POST['numero_U']);
    $descripcion = trim($_POST['descripcion_U']);
    $contrasena_encriptada = password_hash($contrasena, PASSWORD_DEFAULT);
    $token = generarToken();
    $direccion = "$distrito, $avenida, $numero, $descripcion";

    header('Content-Type: application/json');
    $sql = $con->prepare("INSERT INTO usuarios (dni, nombres, apellido_paterno, apellido_materno, celular, fecha_nacimiento, correo, contrasena, genero, direccion, token, rol) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $resultado = $sql->execute([$dni, $nombre, $apellido_paterno, $apellido_materno, $telefono, $fecha_nacimiento, $correo, $contrasena_encriptada, $genero, $direccion, $token, 'cliente']);


    if ($resultado) {
        //header("Location: ../Admin/repartidores_admin.php");
        echo json_encode(["status" => "success", "message" => "Usuario agregado correctamente"]);
        exit;
    } else {
        //header("Location: ../Admin/repartidores_admin.php");
        echo json_encode(["status" => "error", "message" => "Error al agregar el usuario"]);
        exit;
    }

}

// Realizar consultas y obtener datos necesarios
$sql = $con->prepare("SELECT codigo, foto, id_categoria, descripcion, stock, pventa FROM productos WHERE estado = ?;");

$activo = 1;
$sql->bindParam(1, $activo, PDO::PARAM_INT); // Cambiado PDO::PARAM_TINYINT por PDO::PARAM_INT
$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
/*
$sql->bindParam(1, 1, PDO::PARAM_INT);
$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
*/
// Consulta para obtener las categorías
$categorias = array();
$consultaCategorias = "SELECT * FROM categorias";
$resultadoCategorias = $con->prepare($consultaCategorias);
$resultadoCategorias->execute();
$categoriasData = $resultadoCategorias->fetchAll(PDO::FETCH_ASSOC);
foreach ($categoriasData as $categoria) {
$categorias[$categoria['id_categoria']] = $categoria;
}

$sqlProductosCategoria = $con->prepare("
                SELECT codigo, id_categoria, foto, descripcion, stock, pventa
                FROM productos 
                WHERE id_categoria = :id_categoria
            ");
$sqlProductosCategoria->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
$sqlProductosCategoria->execute();
$productosCategoria = $sqlProductosCategoria->fetchAll(PDO::FETCH_ASSOC);


//Hasta aca nomas eh movido loginusuario_y cree el js de validar y lo llmae al index
// hago esyto por si me olvido que borre
//Ya tambien eh comentado eso que esta arriba fin del asunto
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/landing.css" />
    <link rel="stylesheet" href="css/sb-admin-2.css" />
    <link rel="stylesheet" href="css/chatbot.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Asegúrate de incluir Font Awesome en tu proyecto -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <link rel="stylesheet" href="css/Footer.css" />
    <link rel="stylesheet" href="css/cabeceras.css" />
</head>

<body class="fondo" id="page-top">
    
    <!-- cabeceras -->
    <div class="content fixed-header">

        <!--Primera cabecera-->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top primeraCabecera" 
         style="height: 35px; background-color: #5EBC50 !important;">
        <div class="navbar-nav" style="padding: 10px 20px; text-align: left;">
            <a class="telefono" style="color: white; font-weight: bold; text-decoration: none; font-size: 15px; margin-left: 30px;">
                <i class="fas fa-phone" style="margin-right: 8px;"></i> Llámanos al: 945853331
            </a>
        </div>
        </nav>


        <!-- Segunda cabecera -->
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top segundaCabecera">

            <!-- Logo (visible solo en pantallas medianas y grandes) -->
            <img src="images/logo-completo.png" onclick="redirectToLanding()" alt="Logo" class="navbar-brand logoPrincipal leftImage d-none d-sm-flex" style="height: 75px; width: auto; margin-top: 10px">
            <!-- Logo (visible solo en pantallas celular) -->
            <img src="images/Icons/logo-icono.png" onclick="redirectToLanding()" alt="Logo" class="navbar-brand logoPrincipal leftImage d-sm-none" style="height: 50px; width: auto;">
            <!-- Fondo oscurecido -->
            <div id="overlay"></div>
            <!-- Apartado buscar -->
           
            <div class="form-container">
                <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="" method="post" autocomplete="off">
                    <div class="input-group search-wrapper">
                        <input type="text" class="form-control bg-light border-0 small" placeholder="Busca un producto..." aria-label="Search" aria-describedby="basic-addon2" name="campo" id="campo">
                        <div class="input-group-append">
                            <button class="btn bg-custom-color" type="button">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                    <ul id="lista" class="list-group"></ul>
                </form>
            </div>
          
            <!-- CSS -->
             
            <style>
                /* Fondo oscurecido */
                #overlay {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.6);
                    display: none;
                    z-index: 10;
                }

                /* Estilos de la barra de búsqueda */
                .form-container {
                    position: relative;
                    z-index: 20;
                }

                .navbar-search {
                    width: 300px; /* Tamaño inicial */
                    transition: width 0.3s ease-in-out;
                }

                .navbar-search.expanded {
                    width: 600px; /* Tamaño expandido */
                }

                .search-input {
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 30px;
                    font-size: 16px;
                }

                .search-btn {
                    border-radius: 50%;
                    padding: 10px;
                }
                
            </style>
            
            <!-- JavaScript -->
            
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    var searchInput = document.getElementById("campo");
                    var overlay = document.getElementById("overlay");
                    var searchForm = document.querySelector(".navbar-search");

                    searchInput.addEventListener("focus", function () {
                        overlay.style.display = "block"; // Oscurecer fondo
                        searchForm.classList.add("expanded"); // Expandir barra
                    });

                    overlay.addEventListener("click", function () {
                        overlay.style.display = "none"; // Quitar oscurecimiento
                        searchForm.classList.remove("expanded"); // Contraer barra
                        searchInput.blur(); // Quitar el foco del input
                    });
               });
            </script>
            
            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <!-- Nav Item - Search Redirect (Visible Only on Small Screens) -->
                <li class="nav-item d-sm-none">
                    <a class="nav-link" href="buscar.php">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                </li>
            </ul>

            <!-- Botón de Carrito de Compras -->
            <ul class="navbar-nav mx-auto carro-compras">
                <li class="nav-item">
                    <a href="carritodetalles.php">
                        <img src="images/Icons/carro.png" loading="lazy"></a>
                    <span id="num_cart" class="mr-2" style="margin-left: 0.5vh;"><?php echo $num_cart; ?></span>
                </li>
            </ul>


            <!-- Botón de Iniciar Sesión -->
            <ul class="navbar-nav mx-auto login">
                <li class="nav-item">
                    <span data-toggle="modal" data-target="#loginModal">
                        <img src="images/sesion_index.png" alt="Icono Login" class="mr-2 iconos-categorias" style="height: 30px; width: auto; margin-right: 15px;">
                        <span class="iniciar-sesion-text" style="font-size: 13px;">Iniciar Sesión</span>
                    </span>
                </li>
            </ul>

            
        </nav>
    </div>
   
  
    <!--MODAL LOGIN-->
    <div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="loginModalLabel">Iniciar Sesión</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="php/login_usuario_be.php" method="POST" id="loginForm">
                        <div class="form-group">
                            <label for="correo">Correo electrónico</label>
                            <input type="email" class="form-control login-input" id="correo" name="correo" placeholder="Correo electrónico..." required>
                        </div>
                        <div class="form-group">
                            <label for="contrasena">Contraseña</label>
                                <!--Un div se agregó-->
                                <div class="password-container"> 
                                    <input type="password" class="form-control login-input" id="contrasena" name="contrasena" placeholder="Contraseña..." required>
                                    <i class="fa-solid fa-eye" id="showPassword" style="display: none;"></i>
                                    <i class="fa-solid fa-eye-slash" id="hidePassword"></i>
                                </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="button-login">Iniciar Sesión</button>
                        </div>
                    </form>
                    <!-- Contenedor para centrar el contenido -->
                    <div class="text-center" style="font-family: Poppins;">
                        <p>¿No tienes cuenta? <span data-toggle="modal" data-target="#registerModal" class="registrate">Registrate</span></p>
                        <p> ¿Olvidaste tu contraseña?<a href="http://localhost/Cliente/recovery.php"> Recuperar</a></p>
                        <label>Otras opciones para ingresar:</label>
                        <!-- Envuelve los botones en un div con la clase text-center -->
                        <div class="text-center">
                            <button class="btn btn-primary" type="button" id="loginWithFacebook">Ingresar con Facebook</button>
                            <button class="btn btn-danger" type="button" id="loginWithGoogle">Ingresar con Google</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal de Registro -->
    <!-- Modal de Registro -->
    <div id="registerModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="registerModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="registerModalLabel">Registro</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Formulario de registro -->
                    <form id="registerForm">
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="dni_U">DNI</label>
                                <input type="text" class="form-control" id="dni_U" name="dni_U" placeholder="Ingrese su DNI..." required>
                                <span id="validaDni_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="nombres_U">Nombres</label>
                                <input type="text" class="form-control" id="nombres_U" name="nombres_U" placeholder="Ingrese sus nombres..." required>
                                <span id="validaNombres_U" class="text-danger"></span>
                            </div>

                        </div>
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="apellido_paterno_U">Apellido Paterno</label>
                                <input type="text" class="form-control" id="apellido_paterno_U" name="apellido_paterno_U" placeholder="Ingrese su apellido paterno..." required>
                                <span id="validaApellidoPaterno_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="apellido_materno_U">Apellido Materno</label>
                                <input type="text" class="form-control" id="apellido_materno_U" name="apellido_materno_U" placeholder="Ingrese su apellido materno..." required>
                                <span id="validaApellidoMaterno_U" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="row separador">
                            <div class="col-md-6">
                                <label for="celular_U">Número de Celular</label>
                                <input type="text" class="form-control" id="celular_U" name="celular_U" placeholder="Ingrese su número de celular..." 
                                pattern="9[0-9]{8}" maxlength="9" required 
                                oninput="validarCelular(this)">
                                <span id="validaCelular_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="fecha_nacimiento_U">Fecha de Nacimiento</label>
                                <input type="date" class="form-control" id="fecha_nacimiento_U" name="fecha_nacimiento_U" required 
                                    oninput="validarFechaNacimiento()">
                                <span id="validaFechadenacimiento_U" class="text-danger"></span>
                            </div>
                        </div>
                        <div class="row separador">
                            <div class="col-md-6 position-relative">
                                <label for="email_U">Correo Electrónico</label>
                                <input type="email" class="form-control  w-100" id="email_U" name="email_U" placeholder="Ingrese su correo electrónico..." required>
                                <!--<span id="validaEmail_U" class="text-danger"></span>-->
                            </div>
                            <div class="col-md-6 position-relative">
                                <label for="password_U">Contraseña</label>
                                <input type="password" class="form-control" id="password_U" name="password_U" placeholder="Ingrese su contraseña..." required>
                                <i class="fa-solid fa-eye " id="verPassword" style="display: none;"></i>
                                <i class="fa-solid fa-eye-slash " id="ocultarPassword"></i>
                            </div>
                        </div>
                        <div class="row separador">
                        <span id="validaEmail_U" class="text-danger"></span>
                            <div class="col-md-6 position-relative">
                                <div class="password-icons">
                                    <label for="confirmar_contrasena_U">Confirmar contraseña</label>
                                    <input type="password" class="form-control" id="confirmar_contrasena_U" name="confirmar_contrasena_U" placeholder="Repita la contraseña..." required>
                                    <div class="password-icons">
                                        <i class="fa-solid fa-eye" id="mostIcon" style="display: none;"></i>
                                        <i class="fa-solid fa-eye-slash" id="oculIcon"></i>
                                    </div>
                                </div>
                                <span id="validaPassword_U" class="text-danger"></span>
                            </div>
                            <div class="col-md-6">
                                <label for="genero_U">Género</label><br>
                                <select class="register-comboBox" id="genero_U" name="genero_U" required>
                                    <option value="" disabled selected>Seleccionar Género</option>
                                    <option value="masculino">Masculino</option>
                                    <option value="femenino">Femenino</option>
                                    <option value="otro">Otro</option>
                                </select>
                            </div>
                            <div class="row separador">
                                <div class="col-md-6 position-relative">
                                    <label for="distrito_U">Distrito</label>
                                    <input type="text" class="form-control" id="distrito_U" name="distrito_U" placeholder="Ingrese el distrito..." required>
                                    <span id="validaDistrito_U" class="text-danger"></span>
                                </div>
                                <div class="col-md-6">
                                    <label for="avenida_U">Avenida</label><br>
                                    <input type="text" class="form-control" id="avenida_U" name="avenida_U" placeholder="Ingrese la avenida..." required>
                                    <span id="validaAvenida_U" class="text-danger"></span>
                                </div>
                            </div>
                            <div class="row separador">
                                <div class="col-md-6 position-relative">
                                    <label for="numero_U">Numero</label>
                                    <input type="text" class="form-control" id="numero_U" name="numero_U" placeholder="Ingrese numero de casa..." required>
                                    <span id="validaNumero_U" class="text-danger"></span>
                                </div>
                                <div class="col-md-6">
                                    <label for="descripcion_U">Dpto/Interior/Piso/Lote/Bloque</label><br>
                                    <input type="text" class="form-control" id="descripcion_U" name="descripcion_U" placeholder="Describa su casa..." required>
                                    <span id="validaDescripcion_U" class="text-danger"></span>
                                </div>
                                <!-- Puedes agregar más campos aquí -->
                            </div>
                        </div>
                        <button type="submit" class="button-register ">Crear cuenta</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- cabecera 3 -->
    <div class="content">
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow categoriasCabecera" style="padding: 35px; min-height: 90px;">

            <div class="navbar-nav mx-auto cetegoriasGrupo">
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                        Productos
                    </button>
                    <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                        <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                            Computación
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                            Electrónica
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToNutricion()">
                            Electricidad
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToBelleza()">
                            Ferretería
                        </div>
                        <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                            Redes y Telec.
                        </div>
                    </div>
                </div>
            </div>

            <ul class="navbar-nav mx-auto cetegoriasGrupo">
                <li class="nav-item">
                    <a class="btn btn-categoria" href="#">
                        Quienes somos
                    </a>
                </li>
                <li class="nav-item">
                    <div class="navbar-nav mx-auto cetegoriasGrupo">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                                Servicios
                            </button>
                            <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                                <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                                    Computadoras
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                                    Electrodomésticos
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToNutricion()">
                                    Redes y Telec.
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToBelleza()">
                                    Eléctricas
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                                    Sist. Seguridad
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToAromaterapia()">
                                    Ases. Ing. Sistemas.
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                <div class="navbar-nav mx-auto cetegoriasGrupo">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle" type="button" id="categoriasDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #696969; font-size: 16px; font-weight: bold;  margin-top: 10px;"> 
                                Proyectos
                            </button>
                            <div class="dropdown-menu" aria-labelledby="categoriasDropdown" style="right: auto !important; left: 0 !important; min-width: 200px;">
                                <div class="dropdown-item grupos" onclick="redirectToFarmacia()">
                                    Ingeniería Civil
                                </div>
                                <div class="dropdown-item grupos" onclick="redirectToSuplementos()">
                                    Ingeniería Sistemas
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="btn btn-categoria" href="#">
                        Contactenos
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <!-- fin cabecera 3 -->
    <!--<div class="carousel-container">
        <div class="carousel">
            <div class="slide"><img src="images/carrusel1.jpg" alt="Slide 1" loading="lazy"></div>
            <div class="slide"><img src="images/carrusel2.jpg" alt="Slide 2" loading="lazy"></div>
            <div class="slide"><img src="images/carrusel3.jpg" alt="Slide 3" loading="lazy"></div>
            <div class="slide"><img src="images/carrusel4.jpg" alt="Slide 4" loading="lazy"></div>
        </div>

        <div class="arrow arrow-left">&#9664;</div>
        <div class="arrow arrow-right">&#9654;</div>
    </div>-->


    <!-- Apartado de las tarjetas/productos -->
    <div class="container" style="margin-top: 8vh;">
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
            <?php foreach ($resultado as $row) : ?>
                <div class="col">
                    <div class="card h-100" style="max-width: 250px;"> <!-- Agregamos el estilo inline -->
                        <?php
                        $id_categoria_producto = $row['id_categoria'];
                        if (isset($categorias[$id_categoria_producto])) {
                            $categoria_producto = $categorias[$id_categoria_producto];
                            $nombre_categoria = $categoria_producto['nombre_categoria'];
                        } else {
                            $nombre_categoria = 'Categoría Desconocida';
                        }
                        $directorioImagenes = "Admin/";
                        $imagenBD = $row['foto'];

                        // Verificar si hay una imagen en la base de datos
                        if (empty($imagenBD)) {

                            $imagen = "images/nophoto.jpg"; // Imagen por defecto
                        } else {
                            $imagen = $directorioImagenes . $imagenBD;

                            // Verifica si la imagen realmente existe en la carpeta
                            if (!file_exists($imagen)) {
                                echo "<p style='color:red;'>⚠️ Imagen no encontrada: $imagen</p>";
                                $imagen = "images/nophoto.jpg";
                            }
                        }
                        ?>
                        <!-- Agregar enlace alrededor de la imagen -->
                        <a href="detalles.php?codigo=<?php echo $row['codigo']; ?>&token=<?php echo hash_hmac('sha1', $row['codigo'], KEY_TOKEN); ?>">
                            <img src="<?= $imagen ?>" class="card-img-top img-producto" alt="Imagen del producto" loading="lazy">
                        </a>
                        <div class="card-body">
                            <h5 class="card-title"><?= $row['descripcion'] ?></h5>
                            <p class="card-text">S/<?= $row['pventa'] ?></p>
                            <div class="d-grid">
                                <button class="btn-primary btn-productos" type="button" onclick="addProducto(<?= $row['codigo']; ?>, '<?= hash_hmac('sha1', $row['codigo'], KEY_TOKEN); ?>')">Agregar al carrito</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="chatbot-ocultacion.js"></script>

    <!--Contenedor del chatbot -->
    <div class="chatbot-container" id="chatbot">
        <div class="chatbot-header">Nuestros canales de atención</div>
        <div class="chatbot-links">
            <a href="javascript:void(0);">📞 945853331</a>
            <a href="https://wa.me/993207538?text=Hola,%20quiero%20obtener%20más%20información." target="_blank">📱 WhatsApp</a>
            <a href="https://www.facebook.com/profile.php?id=61552772167929" target="_blank">📘 Facebook</a>
        </div>
    </div>
    
    <button class="chatbot-button" id="chatbotToggle">💬</button>
    
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const chatbotButton = document.querySelector(".chatbot-button");
            const chatbotContainer = document.querySelector(".chatbot-container");

            chatbotButton.addEventListener("click", function () {
                chatbotContainer.classList.toggle("show");
            });
        });
    </script>
    

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let chatbotButton = document.querySelector(".chatbot-button");
            let chatbotContainer = document.querySelector(".chatbot-container");
            let footer = document.querySelector("footer"); // Asegúrate de que el footer tenga esta etiqueta

            if (chatbotButton && chatbotContainer && footer) {
                let observer = new IntersectionObserver(
                    function (entries) {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                // Oculta el botón y el contenedor del chatbot
                                chatbotButton.classList.add("fadeOut");
                                chatbotContainer.classList.add("fadeOut");
                            } else {
                                // Muestra el botón y el contenedor del chatbot cuando el footer deja de estar visible
                                chatbotButton.classList.remove("fadeOut");
                                chatbotContainer.classList.remove("fadeOut");
                            }
                        });
                    },
                    { threshold: 0.1 } // Se activa cuando el 10% del footer es visible
                );

                observer.observe(footer);
            }
        });
    </script>


<footer class="pie-pagina">
    <div class="grupo-1">
        <div class="row">
            <!-- Primera Parte: Auxilium Farma (visible en pantallas grandes) -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">La Empresa</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1"  >Quienes somos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Contactos</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1"  >Contáctenos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>

            <!-- Segunda Parte: Inkafarma Digital (visible en pantallas grandes) -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Productos</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Computación</a><br>
                                        <a target="_blank" class="paragraph--1" >Electronica</a><br>
                                        <a target="_blank" class="paragraph--1" >Electricidad</a><br>
                                        <a target="_blank" class="paragraph--1" >Ferretería</a><br>
                                        <a target="_blank" class="paragraph--1" >Redes y Telecomunicaciones</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>
            <!-- Tercera Parte: Contáctanos e Inkafono -->
            <div class="col-11 col-md-3 d-none d-md-block">
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Servicio Técnico</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Computadoras</a><br>
                                        <a target="_blank" class="paragraph--1" >Electrodomésticos</a><br>
                                        <a target="_blank" class="paragraph--1" >Plan de Referidos</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
                <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
                    <mat-expansion-panel class="mat-expansion-panel">
                        <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                            <span class="mat-content">
                                <mat-panel-title class="mat-expansion-panel-header-title">
                                    <h3 class="label-black title mb-lg-3">Instalaciones</h3>
                                </mat-panel-title>
                            </span>
                        </mat-expansion-panel-header>
                        <div class="mat-expansion-panel-content">
                            <div class="mat-expansion-panel-body">
                                <mat-panel-description>
                                    <div class="link">
                                        <a target="_blank" class="paragraph--1" >Redes y Telecomunicaciones</a><br>
                                        <a target="_blank" class="paragraph--1" >Eléctricas</a><br>
                                        <a target="_blank" class="paragraph--1" >Sistemas de seguridad</a><br>
                                    </div>
                                </mat-panel-description>
                            </div>
                        </div>
                    </mat-expansion-panel>
                </mat-accordion>
            </div>

            <!-- Cuarta Parte: Síguenos -->
<div class="col-11 col-md-3 d-none d-md-block">
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3">Proyectos</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body">
                    <mat-panel-description>
                        <div class="link">
                            <a target="_blank" class="paragraph--1" >Ingeniería Civil</a><br>
                            <a target="_blank" class="paragraph--1" >Ingeniería de Sistemas</a><br>
                        </div>
                    </mat-panel-description>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3">Asesoría</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body">
                    <mat-panel-description>
                        <div class="link">
                            <a target="_blank" class="paragraph--1" >Asesoría en Ing. de Sistemas</a><br>
                        </div>
                    </mat-panel-description>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
    <mat-accordion displaymode="flat" class="mat-accordion row footer mat-accordion-multi">
        <mat-expansion-panel class="mat-expansion-panel">
            <mat-expansion-panel-header role="button" class="mat-expansion-panel-header mat-focus-indicator mat-expansion-toggle-indicator-after">
                <span class="mat-content">
                    <mat-panel-title class="mat-expansion-panel-header-title">
                        <h3 class="label-black title mb-lg-3 text">Nuestras Redes</h3>
                    </mat-panel-title>
                </span>
            </mat-expansion-panel-header>
            <div class="mat-expansion-panel-content">
                <div class="mat-expansion-panel-body text-center">
                    <a target="_blank" class="social-item d-flex align-items-center" href="https://www.facebook.com/DelgadoElectronic/">
                        <i class="fab fa-facebook-f fa-2x mr-2"></i> Facebook
                    </a>
                    <a target="_blank" class="social-item d-flex align-items-center" href="https://wa.me/945853331?text=Hola,%20quiero%20obtener%20más%20información.">
                        <i class="fab fa-whatsapp fa-2x mr-2"></i> WhatsApp
                    </a>
                </div>
            </div>
        </mat-expansion-panel>
    </mat-accordion>
</div>

                <!-- Contenedor principal del acordeón -->
            <div id="accordionPadre">
                <!-- Sección de Auxilium Farma -->
                <div class="col-12 col-md-3 d-block d-md-none">
                    <div class="accordion" id="accordionSobreAuxilium">
                        <div class="card">
                            <div class="card-header" id="headingAuxilium">
                                <h5 class="mb-0">
                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseAuxilium" aria-expanded="true" aria-controls="collapseAuxilium">
                                        SOBRE AUXILIUM-FARMA
                                    </button>
                                </h5>
                            </div>
                            <div id="collapseAuxilium" class="collapse" aria-labelledby="headingAuxilium" data-parent="#accordionPadre">
                                <div class="card-body">
                                    <a target="_blank" class="dropdown-item" >Catálogo del mes</a>
                                    <a target="_blank" class="dropdown-item" >Boticas 24 horas</a>
                                    <a target="_blank" class="dropdown-item" >Farmacia Vecina</a>
                                    <a target="_blank" class="dropdown-item" >Apoyo al Paciente</a>
                                    <a target="_blank" class="dropdown-item" >Productos Equivalentes</a>
                                    <a target="_blank" class="dropdown-item" >Derechos Arco</a>
                                    <a target="_blank" class="dropdown-item" >Intercorp y socios estratégicos</a>
                                    <a target="_blank" class="dropdown-item" >Call Center - Términos y Condiciones</a>
                                    <a target="_blank" class="dropdown-item" >Auxilium club</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!-- Sección de Inkafarma Digital -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionInkafarmaDigital">
                    <div class="card">
                        <div class="card-header" id="headingInkafarmaDigital">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseInkafarmaDigital" aria-expanded="true" aria-controls="collapseInkafarmaDigital">
                                    AUXILIUM-FARMA DIGITAL
                                </button>
                            </h5>
                        </div>
                        <div id="collapseInkafarmaDigital" class="collapse" aria-labelledby="headingInkafarmaDigital" data-parent="#accordionPadre">
                            <div class="card-body">
                                <a target="_blank" class="dropdown-item"  >Blog Auxiliumfarma</a>
                                <a target="_blank" class="dropdown-item"  >Legales de Campañas</a>
                                <a target="_blank" class="dropdown-item"  >Retiro en Tienda</a>
                                <a target="_blank" class="dropdown-item"  >Servicio Express</a>
                                <a target="_blank" class="dropdown-item"  >Zonas de cobertura</a>
                                <a target="_blank" class="dropdown-item"  >Términos y Condiciones Generales</a>
                                <a target="_blank" class="dropdown-item"  >Políticas de privacidad</a>
                                <a target="_blank" class="dropdown-item"  >Comprobante electrónico</a>
                                <a target="_blank" class="dropdown-item"  >Terceros encargados de tratamiento</a>
                                <a target="_blank" class="dropdown-item"  >Términos y condiciones de otros sellers</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección de Contactanos -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionContactanos">
                    <div class="card">
                        <div class="card-header" id="headingContactanos">
                            <h5 class="mb-0">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseContactanos" aria-expanded="true" aria-controls="collapseContactanos">
                                    CONTACTANOS
                                </button>
                            </h5>
                        </div>
                        <div id="collapseContactanos" class="collapse" aria-labelledby="headingContactanos" data-parent="#accordionPadre">
                            <div class="card-body">
                                <a target="_blank" class="dropdown-item"  >Preguntas Frecuentes</a>
                                <a target="_blank" class="dropdown-item"  >Información Médica</a>
                                <a target="_blank" class="dropdown-item"  >Plan de Referidos</a>
                                <div class="dropdown-item">
                                    <span class="font-weight-bold">Auxiliumfono (Lima)</span>
                                    <span>(511) 314 2020</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sección de Síguenos -->
            <div class="col-12 col-md-3 d-block d-md-none">
                <div class="accordion" id="accordionSiguenos">
                    <div class="card">
                        <div class="card-header" id="headingSiguenos">
                            <h5 class="mb-0 text-center">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseSiguenos" aria-expanded="true" aria-controls="collapseSiguenos">
                                    SIGUENOS
                                </button>
                            </h5>
                        </div>
                        <div id="collapseSiguenos" class="collapse" aria-labelledby="headingSiguenos" data-parent="#accordionPadre">
                            <div class="card-body text-center">
                                <!-- Ícono de Facebook -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://www.facebook.com/profile.php?id=61552772167929">
                                    <i class="fab fa-facebook-f fa-lg mr-2"></i> Facebook
                                </a>
                                <!-- Ícono de Instagram -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://www.instagram.com/auxiliumfarma.oficial/?next=https%3A%2F%2Fwww.instagram.com%2F">
                                    <i class="fab fa-instagram fa-lg mr-2"></i> Instagram
                                </a>
                                <!-- Ícono de WhatsApp -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center" href="https://wa.me/993207538?text=Hola,%20quiero%20obtener%20más%20información.">
                                    <i class="fab fa-whatsapp fa-lg mr-2"></i> WhatsApp
                                </a>
                                <!-- Métodos de pago -->
                                <a target="_blank" class="dropdown-item d-flex align-items-center justify-content-center">
                                    <i class="fa fa-credit-card fa-lg mr-2" aria-hidden="true"></i> Métodos de Pago
                                </a>
                                <!-- Medios de pago como Yape y Plin -->
                                <div class="mt-3">
                                    <a class="dropdown-item">
                                        <img src="https://play-lh.googleusercontent.com/y5S3ZIz-ohg3FirlISnk3ca2yQ6cd825OpA0YK9qklc5W8MLSe0NEIEqoV-pZDvO0A8" alt="Yape" class="social-icon"> Yape
                                    </a>
                                    <!-- Métodos de pago adicionales -->
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR03J-2Z2fy1C7oO0bpTJXkorFqz7aa6dNOov9KVS6OvYtRKOfIUICxW3fV04YRzsw-s-8&usqp=CAU" alt="Visa" class="social-icon"> Visa
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://i.pinimg.com/736x/56/fd/48/56fd486a48ff235156b8773c238f8da9.jpg" alt="MasterCard" class="social-icon"> MasterCard
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/1200px-American_Express_logo_%282018%29.svg.png" alt="American Express" class="social-icon"> American Express
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9sjRswrzitSNR2m7lgjeU0cPgq_dWMVV6ww&s" alt="Diners Club" class="social-icon"> Diners Club
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://avatars.githubusercontent.com/u/33136169?s=200&v=4" alt="Pago Efectivo" class="social-icon"> Pago Efectivo
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://cdn-1.webcatalog.io/catalog/mercado-pago/mercado-pago-icon-filled-256.webp?v=1740557321644" alt="Plin" class="social-icon"> Mercado Pago
                                    </a>
                                    <a class="dropdown-item">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQN94zsmpdqN7p2ugqBBrPygthpvfIsDB4QJA&s" alt="Plin" class="social-icon"> Plin
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Derechos reservados -->
        <div class="grupo-2 text-center">
            <small>&copy; 2025 <b>Delgado Electronic</b> - Todos los Derechos Reservados.</small>
        </div>
    </div>

</footer>

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bibliotecas externas -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/efe6a408a5.js" crossorigin="anonymous"></script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Tus scripts personalizados -->
    <script src="js/landing.js"></script>
    <script src="js/sb-admin-2.js"></script>
    <script src="js/chatbot-ocultacion.js"></script>
    <script src="js/validacionLogin.js"></script>
    <script src="js/validarRegistro.js"></script>
</body>
</html>