-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-05-2025 a las 06:46:09
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_electronic`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre_categoria` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre_categoria`) VALUES
(1, 'farmacia'),
(2, 'suplementos_vitaminas'),
(3, 'nutricion_deportiva'),
(4, 'cuidado_belleza'),
(5, 'aromaterapia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_ventas`
--

CREATE TABLE `detalles_ventas` (
  `id_detalle_venta` int(11) NOT NULL,
  `id_venta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `descripcion` varchar(200) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `codigo` int(11) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `pventa` decimal(10,2) DEFAULT NULL,
  `desc_web` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`codigo`, `foto`, `id_categoria`, `descripcion`, `stock`, `pventa`, `desc_web`, `estado`) VALUES
(740047, 'images/1.jpg', 1, 'Tarjeta ram', 100, 120.00, 'Tarjeta ram kingstom fury 16fb', 1),
(740048, 'images/2.jpg', 1, 'Tarjeta grafica', 200, 400.00, 'Tarjeta grafica para videojuegos sanpyl rx 580 tarjeta grafica para videojuegos gddr5 de 256 bits de 8 gb', 1),
(740049, 'images/3.jpg', 1, 'Disipador', 400, 40.00, 'Cooler Disipador ALTA 9 (INTEL) para el procesador', 1),
(740050, 'images/4.jpg', 1, 'Mouse gamer', 50, 60.00, 'Mouse Gamer Inalámbrico RGB 7 Botones 8000 DPI Xtrike Me GW-611', 1),
(740051, 'images/5.jpg', 1, 'Teclado gamer', 50, 140.00, 'Klim chroma wireless - teclado inal mbrico gaming espa ol teclado gaming', 1),
(740052, 'images/6.jpg', 1, 'Audifonos', 50, 75.00, 'Audífonos Gamer Xtrike Me GH-711', 1),
(740053, 'images/7.jpg', 1, 'Case gamer', 62, 30.00, 'CASE GAMER CON FUENTE INFINITY 415 - HALION', 1),
(740054, 'images/8.jpg', 1, 'microfono profesional', 23, 220.00, 'MICROFONO PROFESIONAL BM86TZ CON CONDENSADOR + BASE + BRAZO RACK GAMER', 1),
(740055, 'images/9.jpg', 1, 'placa madre', 46, 300.00, 'Placa Pc Motherboard Msi H410M H, Lga1200, H410, Ddr4, Sata 6.0', 1),
(740056, 'images/10.jpg', 1, 'Procesador', 77, 700.00, 'PROCESADOR INTEL CORE I7-960 3.20GHZ/3.46GHZ 8MB LGA1366', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `dni` int(8) NOT NULL,
  `nombres` varchar(50) DEFAULT NULL,
  `apellido_paterno` varchar(50) DEFAULT NULL,
  `apellido_materno` varchar(50) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `contrasena` varchar(150) DEFAULT NULL,
  `genero` enum('Masculino','Femenino','Otro') DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `token` varchar(40) DEFAULT NULL,
  `estado` tinyint(1) DEFAULT 1,
  `rol` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`dni`, `nombres`, `apellido_paterno`, `apellido_materno`, `celular`, `fecha_nacimiento`, `correo`, `contrasena`, `genero`, `direccion`, `token`, `estado`, `rol`) VALUES
(76640517, 'Jefferson', 'Faichin', 'Gonzales', '962779666', '2005-06-15', 'admin1@gmail.com', '$2y$10$ry3PUv2ucAz9c3QKoxbPtO1M/sYMiq5hk5baQJ7wiu0ZKyu.BaQba', 'Masculino', 'Los Olivos, Limares, 987, Piso3', NULL, 1, 'admin'),
(76640518, 'Jefferson3', 'Faichin3', 'Gonzales3', '962779662', '2005-06-15', 'cliente@gmail.com', '$2y$10$ry3PUv2ucAz9c3QKoxbPtO1M/sYMiq5hk5baQJ7wiu0ZKyu.BaQba', 'Masculino', 'Los Olivos, Limares, 987, Piso3', NULL, 1, 'cliente'),
(76640519, 'Jefferson2', 'Faichin2', 'Gonzales2', '962779662', '2005-06-15', 'vendedor@gmail.com', '$2y$10$ry3PUv2ucAz9c3QKoxbPtO1M/sYMiq5hk5baQJ7wiu0ZKyu.BaQba', 'Masculino', 'Los Olivos, Limares, 987, Piso3', NULL, 1, 'vendedor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `id_transaccion` varchar(20) NOT NULL,
  `fecha_venta` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `id_cliente` varchar(20) NOT NULL,
  `direccion_cliente` varchar(80) NOT NULL,
  `total_venta` decimal(10,2) NOT NULL,
  `estado` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `detalles_ventas`
--
ALTER TABLE `detalles_ventas`
  ADD PRIMARY KEY (`id_detalle_venta`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id_venta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalles_ventas`
--
ALTER TABLE `detalles_ventas`
  MODIFY `id_detalle_venta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=740057;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id_venta` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
